<?php
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>404 - Halaman Tidak Ditemukan</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Bootstrap CDN (optional, only if you need Bootstrap components too) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Inter', sans-serif;
    }

    .animate-fade-in {
      animation: fadeIn 0.5s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-gray-50 d-flex align-items-center justify-content-center min-vh-100">
  <div class="bg-white p-4 p-md-5 rounded-4 shadow-lg text-center animate-fade-in" style="max-width: 400px;">
    <div class="mb-4">
      <svg class="w-20 h-20 text-blue-600 mx-auto" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round"
              d="M12 9v2m0 4h.01M2.458 12C3.732 7.943 7.523 5 12 5s8.268 2.943 9.542 7c-1.274 4.057-5.065 7-9.542 7s-8.268-2.943-9.542-7z" />
      </svg>
    </div>
    <h1 class="text-5xl fw-bold text-primary mb-2">404</h1>
    <p class="fs-5 fw-semibold text-dark mb-2">Halaman Tidak Ditemukan</p>
    <p class="text-muted mb-4">Sepertinya halaman yang kamu cari sudah dipindahkan atau tidak tersedia.</p>
    <a href="/" class="btn btn-primary rounded-pill px-4 py-2">
      Kembali ke Beranda
    </a>
  </div>
</body>
</html>