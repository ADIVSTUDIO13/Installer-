<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuration
$defaultRateLimit = 60;
$rateLimitWindow = 60;
$baseDir = __DIR__;

// Get request parameters
$endpoint = isset($_GET['endpoint']) ? strtolower(trim($_GET['endpoint'])) : null;
$apikey = isset($_GET['apikey']) ? trim($_GET['apikey']) : null;

/**
 * Validate API key format
 */
function validateApiKey($apikey) {
    return preg_match('/^API-[a-f0-9]{16}$/i', $apikey);
}

/**
 * Ensure directory exists and is writable
 */
function ensureDirectoryExists($dirPath) {
    if (!file_exists($dirPath)) {
        if (!mkdir($dirPath, 0755, true)) {
            throw new Exception("Failed to create directory: $dirPath");
        }
    }
    if (!is_writable($dirPath)) {
        throw new Exception("Directory not writable: $dirPath");
    }
}

/**
 * Get rate limit for API key from configuration file
 */
function getRateLimitFromFile($apikey, $defaultLimit = 60) {
    global $baseDir;
    $filePath = $baseDir . '/apikey/limit.json';
    if (!file_exists($filePath)) {
        return $defaultLimit;
    }

    $content = file_get_contents($filePath);
    if ($content === false) {
        return $defaultLimit;
    }

    $limits = json_decode($content, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return $defaultLimit;
    }

    return $limits[$apikey] ?? $defaultLimit;
}

/**
 * Check and enforce rate limiting
 */
function checkRateLimit($apikey, $defaultRateLimit, $rateLimitWindow) {
    global $baseDir;
    $rateLimit = getRateLimitFromFile($apikey, $defaultRateLimit);
    $cacheDir = $baseDir . '/rate_limit_cache/';
    
    try {
        ensureDirectoryExists($cacheDir);
    } catch (Exception $e) {
        error_log($e->getMessage());
        return true;
    }

    $cacheFile = $cacheDir . md5($apikey) . '.json';
    $currentTime = time();
    $data = ['count' => 1, 'timestamp' => $currentTime];

    if (file_exists($cacheFile)) {
        $fileContent = file_get_contents($cacheFile);
        if ($fileContent !== false) {
            $existingData = json_decode($fileContent, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                if ($currentTime - $existingData['timestamp'] < $rateLimitWindow) {
                    if ($existingData['count'] >= $rateLimit) {
                        http_response_code(429);
                        echo json_encode([
                            'status' => 'error',
                            'message' => 'API rate limit exceeded',
                            'creator' => 'aryastore',
                            'code' => 429
                        ]);
                        exit;
                    }
                    $data = ['count' => $existingData['count'] + 1, 'timestamp' => $existingData['timestamp']];
                }
            }
        }
    }

    file_put_contents($cacheFile, json_encode($data));
    return true;
}

/**
 * Log API requests
 */
function logRequest($apikey, $endpoint) {
    global $baseDir;
    $logDir = $baseDir . '/logs/';
    
    try {
        ensureDirectoryExists($logDir);
    } catch (Exception $e) {
        error_log($e->getMessage());
        return;
    }

    $logFile = $logDir . 'access.log';
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $time = date('Y-m-d H:i:s');
    $log = "[$time] IP: $ip | APIKEY: $apikey | Endpoint: " . ($endpoint ?? 'none') . "\n";
    
    @file_put_contents($logFile, $log, FILE_APPEND);
}

/**
 * Call external API
 */
function callExternalAPI($apiUrl, $isBinary = false) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        throw new Exception('cURL Error: ' . $error, 500);
    }
    if ($httpCode !== 200) {
        throw new Exception("External API error: HTTP $httpCode", $httpCode);
    }

    return $isBinary ? ['data' => $response, 'content_type' => $contentType] : $response;
}

/**
 * Get server runtime information
 */
function getServerRuntime() {
    $uptime = @shell_exec("uptime -p") ?: @shell_exec("uptime") ?: "Uptime information not available";
    if (strpos($uptime, 'up') === 0) {
        $uptime = trim(str_replace(['up', '  '], ['', ' '], $uptime));
    }

    preg_match('/(\d+ days?,)?\s*(\d+ hours?,)?\s*(\d+ minutes?)/', $uptime, $matches);
    
    $days = isset($matches[1]) ? (int) filter_var($matches[1], FILTER_SANITIZE_NUMBER_INT) : 0;
    $hours = isset($matches[2]) ? (int) filter_var($matches[2], FILTER_SANITIZE_NUMBER_INT) : 0;
    $minutes = isset($matches[3]) ? (int) filter_var($matches[3], FILTER_SANITIZE_NUMBER_INT) : 0;
    
    $formattedUptime = '';
    if ($days > 0) {
        $formattedUptime .= "$days hari ";
    }
    if ($hours > 0) {
        $formattedUptime .= "$hours jam ";
    }
    if ($minutes > 0) {
        $formattedUptime .= "$minutes menit";
    }
    
    $load = @sys_getloadavg() ?: [0, 0, 0];
    $cpuModel = 'Unknown';
    if (is_readable('/proc/cpuinfo')) {
        $cpuinfo = @file_get_contents('/proc/cpuinfo');
        if ($cpuinfo) {
            preg_match('/model name\s*:\s*(.*)/', $cpuinfo, $matches);
            if (isset($matches[1])) {
                $cpuModel = trim($matches[1]);
            }
        }
    } else {
        $cpuModel = @shell_exec('sysctl -n machdep.cpu.brand_string') ?: 'Unknown';
    }

    $ramTotal = 'Unknown';
    $ramFree = 'Unknown';
    if (is_readable('/proc/meminfo')) {
        $meminfo = @file_get_contents('/proc/meminfo');
        if ($meminfo) {
            preg_match('/MemTotal:\s+(\d+)\s+kB/', $meminfo, $total);
            preg_match('/MemAvailable:\s+(\d+)\s+kB/', $meminfo, $free);
            if (isset($total[1])) {
                $ramTotal = round($total[1] / 1024) . ' MB';
            }
            if (isset($free[1])) {
                $ramFree = round($free[1] / 1024) . ' MB';
            }
        }
    } else {
        $ramInfo = @shell_exec('sysctl hw.memsize');
        if ($ramInfo) {
            preg_match('/hw.memsize: (\d+)/', $ramInfo, $matches);
            if (isset($matches[1])) {
                $ramTotal = round($matches[1] / (1024 * 1024)) . ' MB';
            }
        }
    }

    return [
        'status' => 'success',
        'creator' => 'aryastore',
        'runtime' => $formattedUptime,
        'load_average' => $load,
        'server_time' => date('Y-m-d H:i:s'),
        'php_version' => phpversion(),
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'hardware' => [
            'cpu_model' => $cpuModel,
            'memory' => [
                'total' => $ramTotal,
                'available' => $ramFree
            ]
        ]
    ];
}

// Main execution
try {
    // Validate API key once
    if (!$apikey || !validateApiKey($apikey)) {
        throw new Exception('Invalid API key', 401);
    }

    // Check rate limit and log request
    checkRateLimit($apikey, $defaultRateLimit, $rateLimitWindow);
    logRequest($apikey, $endpoint);

    switch ($endpoint) {
        case 'list':
            $response = [
                'status' => 'success',
                'creator' => 'aryastore',
                'apis' => [
                    ['name' => 'user', 'description' => 'Menampilkan data pengguna dummy', 'parameters' => 'apikey'],
                    ['name' => 'weather', 'description' => 'Informasi cuaca berdasarkan kota', 'parameters' => 'apikey, city'],
                    ['name' => 'joke', 'description' => 'Joke acak', 'parameters' => 'apikey'],
                    ['name' => 'tiktok', 'description' => 'Unduh video TikTok', 'parameters' => 'apikey, url'],
                    ['name' => 'ytmp3', 'description' => 'Konversi YouTube ke MP3', 'parameters' => 'apikey, url'],
                    ['name' => 'terabox', 'description' => 'Unduh file Terabox', 'parameters' => 'apikey, url'],
                    ['name' => 'mediafire', 'description' => 'Unduh file MediaFire', 'parameters' => 'apikey, url'],
                    ['name' => 'github', 'description' => 'Mengambil informasi dari GitHub', 'parameters' => 'apikey, url'],
                    ['name' => 'deepseek', 'description' => 'Chat AI DeepSeek', 'parameters' => 'apikey, prompt'],
                    ['name' => 'claudeai', 'description' => 'Chat AI Claude Sonnet', 'parameters' => 'apikey, prompt'],
                    ['name' => 'spotify', 'description' => 'Cari lagu Spotify', 'parameters' => 'apikey, query'],
                    ['name' => 'spotifydl', 'description' => 'Unduh lagu Spotify', 'parameters' => 'apikey, url'],
                    ['name' => 'hd', 'description' => 'Upscale Gambar HD', 'parameters' => 'apikey, url'],
                    ['name' => 'infogempa', 'description' => 'Informasi gempa terbaru dari BMKG', 'parameters' => 'apikey'],
                    ['name' => 'runtime', 'description' => 'Menampilkan informasi runtime server', 'parameters' => 'apikey'],
                    ['name' => 'kecocokanpasangan', 'description' => 'Cek kecocokan nama pasangan', 'parameters' => 'apikey, nama1, nama2'],
                    ['name' => 'artinama', 'description' => 'Cek arti nama', 'parameters' => 'apikey, name'],
                    ['name' => 'removebg', 'description' => 'Remove background from images', 'parameters' => 'apikey, url'],
                    ['name' => 'pinterest', 'description' => 'Cari gambar di Pinterest', 'parameters' => 'apikey, query'],
                    ['name' => 'twitter', 'description' => 'Unduh video dari Twitter', 'parameters' => 'apikey, url'],
                    ['name' => 'blackboxai', 'description' => 'Chat AI BlackboxAI', 'parameters' => 'apikey, prompt'],
                    ['name' => 'brat', 'description' => 'Generate video brat dari text', 'parameters' => 'apikey, text, isVideo, delay'],
                    ['name' => 'ssweb', 'description' => 'Ambil screenshot website', 'parameters' => 'apikey, url, theme, device'],
                    ['name' => 'cekapikey', 'description' => 'Cek validitas dan limit penggunaan API key', 'parameters' => 'apikey']
                ]
            ];
            break;
        case 'joke':
            $jokes = [
                'Kenapa developer tidak suka tidur? Karena mimpi bukan realitas.',
                'Berapa banyak programmer yang dibutuhkan untuk mengganti bohlam? Tidak ada, itu masalah hardware.',
                'Kenapa programmer bingung saat musim panas? Karena mereka tidak bisa membedakan antara == dan =',
                'Apa makanan favorit programmer? Cookies!'
            ];
            $response = [
                'status' => 'success',
                'joke' => $jokes[array_rand($jokes)],
                'category' => 'programming',
                'creator' => 'aryastore'
            ];
            break;
        case 'weather':
            if (!isset($_GET['city'])) throw new Exception('Parameter city diperlukan.', 400);
            $city = urlencode($_GET['city']);
            $apiUrl = "https://api.siputzx.my.id/api/info/cuaca?q=$city";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'cekapikey':
            $limit = getRateLimitFromFile($apikey, $defaultRateLimit);
            $cacheFile = $baseDir . '/rate_limit_cache/' . md5($apikey) . '.json';
            $currentCount = 0;
            $resetIn = 0;

            if (file_exists($cacheFile)) {
                $data = json_decode(file_get_contents($cacheFile), true);
                $currentCount = $data['count'];
                $resetIn = max(0, $rateLimitWindow - (time() - $data['timestamp']));
            }

            $response = [
                'status' => 'success',
                'message' => 'API key valid',
                'creator' => 'aryastore',
                'apikey' => $apikey,
                'limit_per_minute' => $limit,
                'current_usage' => $currentCount,
                'reset_in_seconds' => $resetIn,
                'code' => 200
            ];
            break;
        case 'twitter':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/d/twitter?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'brat':
            if (!isset($_GET['text'])) throw new Exception('Parameter text diperlukan.', 400);
            $text = urlencode($_GET['text']);
            $isVideo = isset($_GET['isVideo']) ? urlencode($_GET['isVideo']) : 'false';
            $delay = isset($_GET['delay']) ? urlencode($_GET['delay']) : '500';
            
            $apiUrl = "https://api.siputzx.my.id/api/m/brat?text=$text&isVideo=$isVideo&delay=$delay";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            
            $response = curl_exec($ch);
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headers = substr($response, 0, $headerSize);
            $body = substr($response, $headerSize);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            curl_close($ch);
            
            if ($httpCode !== 200) {
                throw new Exception('Gagal mengambil data dari API', $httpCode);
            }
            
            if (strpos($contentType, 'image/') !== false) {
                header('Content-Type: ' . $contentType);
                echo $body;
                exit;
            } elseif (strpos($contentType, 'video/') !== false) {
                header('Content-Type: ' . $contentType);
                header('Content-Length: ' . strlen($body));
                echo $body;
                exit;
            } else {
                $jsonResponse = json_decode($body, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $jsonResponse['creator'] = 'aryastore';
                    header('Content-Type: application/json');
                    echo json_encode($jsonResponse);
                } else {
                    header('Content-Type: text/plain');
                    echo $body;
                }
            }
            break;
        case 'deepseek':
            if (!isset($_GET['prompt'])) throw new Exception('Parameter prompt diperlukan.', 400);
            $content = urlencode($_GET['prompt']);
            $apiUrl = "https://api.siputzx.my.id/api/ai/deepseek-llm-67b-chat?content=$content";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'ssweb':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $theme = isset($_GET['theme']) ? $_GET['theme'] : 'light';
            $device = isset($_GET['device']) ? $_GET['device'] : 'desktop';
            $apiUrl = "https://api.siputzx.my.id/api/tools/ssweb?url=$url&theme=$theme&device=$device";
            $headers = get_headers($apiUrl, 1);
            if (isset($headers['Content-Type']) && strpos($headers['Content-Type'], 'image') !== false) {
                header('Content-Type: image/png');
                readfile($apiUrl);
                exit;
            } else {
                $response = json_decode(callExternalAPI($apiUrl), true);
                $response['creator'] = 'aryastore';
            }
            break;
        case 'blackboxai':
            if (!isset($_GET['prompt'])) throw new Exception('Parameter prompt diperlukan.', 400);
            $content = urlencode($_GET['prompt']);
            $apiUrl = "https://api.siputzx.my.id/api/ai/blackboxai-pro?content=$content";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'pinterest':
            if (!isset($_GET['query'])) throw new Exception('Parameter query diperlukan.', 400);
            $query = urlencode($_GET['query']);
            $apiUrl = "https://api.siputzx.my.id/api/s/pinterest?query=$query";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'artinama':
            if (!isset($_GET['name'])) throw new Exception('Parameter name diperlukan.', 400);
            $name = urlencode($_GET['name']);
            $apiUrl = "https://api.siputzx.my.id/api/primbon/artinama?nama=$name";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'claudeai':
            if (!isset($_GET['prompt'])) throw new Exception('Parameter prompt diperlukan.', 400);
            $content = urlencode($_GET['prompt']);
            $apiUrl = "https://api.siputzx.my.id/api/ai/claude-sonnet-37?content=$content";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'spotify':
            if (!isset($_GET['query'])) throw new Exception('Parameter query diperlukan.', 400);
            $query = urlencode($_GET['query']);
            $apiUrl = "https://api.siputzx.my.id/api/s/spotify?query=$query";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'github':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/d/github?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'spotifydl':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/d/spotify?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'terabox':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://restapi-v2.simplebot.my.id/download/terabox?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'ytmp3':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/d/ytmp3?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'mediafire':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.betabotz.eu.org/api/download/mediafire?url=$url&apikey=aryastorea899";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'tiktok':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $url = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/tiktok/v2?url=$url";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        case 'hd':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $image = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/iloveimg/upscale?image=$image";
            $result = callExternalAPI($apiUrl, true);
            header('Content-Type: ' . $result['content_type']);
            echo $result['data'];
            exit;
        case 'removebg':
            if (!isset($_GET['url'])) throw new Exception('Parameter url diperlukan.', 400);
            $imageUrl = urlencode($_GET['url']);
            $apiUrl = "https://api.siputzx.my.id/api/iloveimg/removebg?image=$imageUrl&scale=2";
            $result = callExternalAPI($apiUrl, true);
            header('Content-Type: ' . $result['content_type']);
            echo $result['data'];
            exit;
        case 'infogempa':
            $apiUrl = "https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json";
            $result = json_decode(callExternalAPI($apiUrl), true);
            if (!isset($result['Infogempa']['gempa'])) {
                throw new Exception('Gagal mengambil data gempa.', 500);
            }
            $response = [
                'status' => 'success',
                'creator' => 'aryastore',
                'data' => $result['Infogempa']['gempa']
            ];
            break;
        case 'runtime':
            $response = getServerRuntime();
            break;
        case 'kecocokanpasangan':
            if (!isset($_GET['nama1']) || !isset($_GET['nama2'])) throw new Exception('Parameter nama1 dan nama2 diperlukan.', 400);
            $nama1 = urlencode($_GET['nama1']);
            $nama2 = urlencode($_GET['nama2']);
            $apiUrl = "https://api.siputzx.my.id/api/primbon/kecocokan_nama_pasangan?nama1=$nama1&nama2=$nama2";
            $response = json_decode(callExternalAPI($apiUrl), true);
            $response['creator'] = 'aryastore';
            break;
        default:
            throw new Exception('Endpoint tidak ditemukan.', 404);
    }

    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'creator' => 'aryastore',
        'code' => $e->getCode() ?: 500
    ]);
}
?>