<?php
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>403 Forbidden</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    @keyframes float {
      0% { transform: translateY(0); }
      50% { transform: translateY(-10px); }
      100% { transform: translateY(0); }
    }
    .float {
      animation: float 2s ease-in-out infinite;
    }
  </style>
</head>
<body class="bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center min-h-screen">
  <div class="bg-white p-8 rounded-2xl shadow-xl text-center max-w-md w-full">
    <div class="w-28 mx-auto mb-6 float">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
        <circle cx="32" cy="32" r="30" fill="#F87171" />
        <path d="M20 20L44 44M44 20L20 44" stroke="#fff" stroke-width="4" stroke-linecap="round"/>
      </svg>
    </div>
    <h1 class="text-5xl font-extrabold text-red-600 mb-2">403</h1>
    <p class="text-xl font-medium text-gray-700 mb-4">Forbidden</p>
    <p class="text-gray-500 mb-6">Oops! You don’t have permission to access this page.</p>
    <a href="/" class="inline-block px-6 py-3 bg-red-500 hover:bg-red-600 text-white text-sm font-semibold rounded-lg transition">
      Go Back Home
    </a>
  </div>
</body>
</html>