<?php
session_start();
require_once 'vendor/autoload.php';

// Enkripsi
$key = '83929292922';
$method = 'AES-256-CBC';
$iv = '1234567890123456';
$hmacKey = '01100001';

$usersFile = 'users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) ?? [] : [];

// Google OAuth Configuration
$googleClient = new Google_Client();
$googleClient->setClientId('62521056555-humtm3rt960qmrm9el4o5lg1q3o5n95i.apps.googleusercontent.com');
$googleClient->setClientSecret('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');
$googleClient->setRedirectUri('https://api.aryastore.biz.id/callback.php'); // Ensure this matches Google Cloud Console
$googleClient->addScope('email');
$googleClient->addScope('profile');

function encrypt($data, $key, $method, $iv, $hmacKey) {
    $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
    $hmac = hash_hmac('sha256', $encrypted, $hmacKey);
    return base64_encode($hmac . ':' . $encrypted);
}

// Handle Google OAuth Callback
if (isset($_GET['code'])) {
    try {
        $token = $googleClient->fetchAccessTokenWithAuthCode($_GET['code']);
        if (!isset($token['error'])) {
            $googleClient->setAccessToken($token);
            $googleService = new Google_Service_Oauth2($googleClient);
            $userInfo = $googleService->userinfo->get();
            $email = $userInfo->email;
            $username = $userInfo->name ?: 'Google User';

            if (isset($users[$email])) {
                // Existing user - log them in
                if ($users[$email]['auth_provider'] === 'google') {
                    $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                    setcookie('user_data', $encryptedUser, time() + 3600, "/");
                    $_SESSION['user'] = $users[$email];
                    header('Location: index.php?page=home');
                    exit();
                } else {
                    header('Location: index.php?page=login&error=' . urlencode('This email is registered with a different provider.'));
                    exit();
                }
            } else {
                // New user - register them
                $users[$email] = [
                    'username' => $username,
                    'email' => $email,
                    'password' => null, // No password for Google users
                    'api_keys' => [],
                    'created_at' => date('Y-m-d H:i:s'),
                    'auth_provider' => 'google'
                ];
                file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
                $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                setcookie('user_data', $encryptedUser, time() + 3600, "/");
                $_SESSION['user'] = $users[$email];
                header('Location: index.php?page=home');
                exit();
            }
        } else {
            header('Location: index.php?page=login&error=' . urlencode('Google authentication failed: ' . ($token['error_description'] ?? 'Unknown error')));
            exit();
        }
    } catch (Exception $e) {
        header('Location: index.php?page=login&error=' . urlencode('An error occurred during authentication: ' . $e->getMessage()));
        exit();
    }
} else {
    header('Location: index.php?page=login&error=' . urlencode('No authorization code provided.'));
    exit();
}
?>