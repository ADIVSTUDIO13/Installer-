<?php
session_start();
require_once 'vendor/autoload.php';

// Konfigurasi enkripsi
$key = '83929292922';
$method = 'AES-256-CBC';
$iv = '1234567890123456';
$hmacKey = '01100001';

// File pengguna
$usersFile = 'users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) ?? [] : [];


$googleClient = new Google_Client();
$googleClient->setClientId('62521056555-humtm3rt960qmrm9el4o5lg1q3o5n95i.apps.googleusercontent.com');
$googleClient->setClientSecret('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');
$googleClient->setRedirectUri('https://api.aryastore.biz.id/google-callback.php');
$googleClient->addScope('email');
$googleClient->addScope('profile');

// Fungsi enkripsi
function encrypt($data, $key, $method, $iv, $hmacKey) {
    $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
    $hmac = hash_hmac('sha256', $encrypted, $hmacKey);
    return base64_encode($hmac . ':' . $encrypted);
}

// Proses callback dari Google
if (isset($_GET['code'])) {
    try {
        $token = $googleClient->fetchAccessTokenWithAuthCode($_GET['code']);
        if (!isset($token['error'])) {
            $googleClient->setAccessToken($token);
            $googleService = new Google_Service_Oauth2($googleClient);
            $userInfo = $googleService->userinfo->get();
            $email = $userInfo->email;
            $username = $userInfo->name ?: 'Google User';

            if (isset($users[$email])) {
                // Pengguna sudah terdaftar
                if ($users[$email]['auth_provider'] === 'google') {
                    // Login berhasil
                    $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                    setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
                    $_SESSION['user'] = $users[$email];
                    header('Location: index.php?page=home');
                    exit();
                } else {
                    // Email terdaftar dengan metode lain
                    header('Location: index.php?page=login&error=' . urlencode('Email ini sudah terdaftar menggunakan metode login lain.'));
                    exit();
                }
            } else {
                // Pengguna baru - buat akun baru
                $users[$email] = [
                    'username' => $username,
                    'email' => $email,
                    'password' => null,
                    'api_keys' => [],
                    'created_at' => date('Y-m-d H:i:s'),
                    'auth_provider' => 'google'
                ];
                file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
                $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
                $_SESSION['user'] = $users[$email];
                header('Location: index.php?page=home');
                exit();
            }
        } else {
            // Gagal ambil token
            header('Location: index.php?page=login&error=' . urlencode('Google authentication failed: ' . ($token['error_description'] ?? 'Unknown error')));
            exit();
        }
    } catch (Exception $e) {
        // Error saat proses login
        header('Location: index.php?page=login&error=' . urlencode('An error occurred during authentication: ' . $e->getMessage()));
        exit();
    }
} else {
    // Tidak ada kode dari Google
    header('Location: index.php?page=login&error=' . urlencode('No authorization code provided.'));
    exit();
}
?>