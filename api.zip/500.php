<?php
http_response_code(500);
$serverTime = date("Y-m-d H:i:s");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
  <title>500 Internal Server Error</title>
  <style>
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    body {
      margin: 0;
      padding: 0;
      background: #1e1e2f;
      color: #fff;
      font-family: 'Poppins', sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .card {
      background: #2a2a40;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
      max-width: 500px;
      text-align: center;
      animation: fadeInUp 0.6s ease-out;
    }

    .card svg {
      width: 80px;
      height: 80px;
      margin-bottom: 20px;
      fill: #ff6b6b;
    }

    .card h1 {
      font-size: 3.5rem;
      margin: 0;
      color: #ff6b6b;
    }

    .card p {
      font-size: 1.1rem;
      margin: 10px 0;
      color: #ccc;
    }

    .status {
      margin-top: 25px;
      padding: 15px;
      border-radius: 12px;
      background: #383850;
      color: #bbb;
      font-size: 0.95rem;
    }

    a {
      color: #ff6b6b;
      text-decoration: none;
      font-weight: 500;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="card">
    <svg viewBox="0 0 24 24">
      <path d="M11.001 10h2v5h-2zm0 7h2v2h-2z"/>
      <path d="M12 2C6.477 2 2 6.478 2 12c0 5.523 
               4.477 10 10 10s10-4.477 10-10c0-5.522-4.477-10-10-10zm0 
               18c-4.411 0-8-3.589-8-8s3.589-8 
               8-8 8 3.589 8 8-3.589 8-8 8z"/>
    </svg>
    <h1>500</h1>
    <p>Maaf, terjadi kesalahan internal pada server kami.</p>
    <p>Silakan kembali ke <a href="/">beranda</a> atau coba beberapa saat lagi.</p>

    <div class="status">
      <strong>Status Server:</strong><br>
      Kode: 500 Internal Server Error<br>
      Waktu Server: <?= $serverTime ?>
    </div>
  </div>
</body>
</html>