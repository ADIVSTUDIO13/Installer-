<?php
// admin.php - Halaman Admin untuk Update Version
session_start();

// Autentikasi sederhana
$valid_username = "admin";
$valid_password = "password123"; // Ganti dengan password yang kuat

// Cek login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if ($_POST['username'] === $valid_username && $_POST['password'] === $valid_password) {
        $_SESSION['logged_in'] = true;
    } else {
        $login_error = "Username atau password salah!";
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// Update version.json
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_version']) && isset($_SESSION['logged_in'])) {
    $new_version = $_POST['version'];
    $new_download_url = $_POST['download_url'];
    
    $version_data = [
        "version" => $new_version,
        "download_url" => $new_download_url
    ];
    
    file_put_contents('version.json', json_encode($version_data, JSON_PRETTY_PRINT));
    $success_message = "Version berhasil diupdate!";
}

// Baca data saat ini
$current_data = [
    "version" => "1.0.0",
    "download_url" => ""
];

if (file_exists('version.json')) {
    $file_content = file_get_contents('version.json');
    $current_data = json_decode($file_content, true);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Version Management</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 8px; }
        button { padding: 8px 15px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        .error { color: red; }
        .success { color: green; }
        .login-form { border: 1px solid #ddd; padding: 20px; margin-top: 50px; }
        .version-form { border: 1px solid #ddd; padding: 20px; margin-top: 20px; }
    </style>
</head>
<body>
    <h1>Version Management Admin</h1>
    
    <?php if (!isset($_SESSION['logged_in'])): ?>
        <div class="login-form">
            <h2>Login</h2>
            <?php if (isset($login_error)): ?>
                <p class="error"><?= htmlspecialchars($login_error) ?></p>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" name="login">Login</button>
            </form>
        </div>
    <?php else: ?>
        <p>Anda login sebagai admin. <a href="admin.php?logout=1">Logout</a></p>
        
        <div class="version-form">
            <h2>Update Version</h2>
            <?php if (isset($success_message)): ?>
                <p class="success"><?= htmlspecialchars($success_message) ?></p>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Version Number:</label>
                    <input type="text" name="version" value="<?= htmlspecialchars($current_data['version'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>Download URL:</label>
                    <input type="text" name="download_url" value="<?= htmlspecialchars($current_data['download_url'] ?? '') ?>" required>
                </div>
                <button type="submit" name="update_version">Update Version</button>
            </form>
        </div>
        
        <div style="margin-top: 30px;">
            <h3>Current version.json:</h3>
            <pre><?= file_exists('version.json') ? htmlspecialchars(file_get_contents('version.json')) : 'File not found' ?></pre>
        </div>
    <?php endif; ?>
</body>
</html>