<?php
session_start();
$page = $_GET['page'] ?? 'landing';


// Daftar halaman yang diizinkan
$allowedPages = [
    'landing', 
    'register', 
    'login', 
    'forgot-password', 
    'reset-password', 
    'home', 
    'google-callback', 
    'github-callback', 
    'verify', 
    'verify-pending',
    'terms-of-service',
    'jumlahuser'
];
if (!in_array($page, $allowedPages)) {
    http_response_code(404);
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>404 Tidak Ditemukan</title>
    <meta name="google-site-verification" content="wftVB1A-HjA7S96f81oRs8dkZ5S9UDoBSLRE0Vlz7-c" />
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/2748/2748558.png" type="image/png">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      color: #ffffff;
      overflow: hidden;
    }
    canvas#stars {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: -1;
      opacity: 0.5;
    }
    .container-404 {
      height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      padding: 0 20px;
    }
    .icon {
      width: 180px;
      height: 180px;
      margin-bottom: 20px;
    }
    h1 {
      font-size: 5rem;
      margin: 0;
      color: #ff6b6b;
      text-shadow: 0 0 10px rgba(255, 107, 107, 0.4);
    }
    p {
      font-size: 1.3rem;
      margin: 15px 0 30px;
      max-width: 500px;
    }
    a.btn-custom {
      padding: 0.8rem 2rem;
      background: #00c896;
      color: white;
      border-radius: 12px;
      font-weight: 600;
      box-shadow: 0 0 15px rgba(0, 200, 150, 0.4);
      transition: 0.3s ease;
    }
    a.btn-custom:hover {
      background: #00e0aa;
      box-shadow: 0 0 20px rgba(0, 224, 170, 0.6);
      color: white;
    }
    @media (max-width: 600px) {
      h1 {
        font-size: 3.5rem;
      }
      .icon {
        width: 140px;
        height: 140px;
      }
    }
  </style>
</head>
<body>
  <canvas id="stars"></canvas>
  <div class="container-404">
    <img class="icon" src="https://undraw.co/api/illustrations/0c84d928-e2ae-4c63-b2c0-bb3f8dc00f16" alt="404 Illustration">
    <h1>404</h1>
    <p>Oops! Halaman yang kamu cari tidak tersedia atau telah dipindahkan.</p>
    <a href="?page=landing" class="btn btn-custom">Kembali ke Beranda</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script>
    const canvas = document.getElementById('stars');
    const ctx = canvas.getContext('2d');
    let stars = [];

    function resizeCanvas() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    for (let i = 0; i < 120; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.5,
        s: Math.random() * 0.7 + 0.3
      });
    }

    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#fff";
      stars.forEach(star => {
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.r, 0, Math.PI * 2);
        ctx.fill();
        star.y += star.s;
        if (star.y > canvas.height) {
          star.y = 0;
          star.x = Math.random() * canvas.width;
        }
      });
      requestAnimationFrame(animate);
    }

    animate();
  </script>
</body>
</html>
<?php 
exit;
}

require_once 'vendor/autoload.php'; // Load Google API Client Library
use SendGrid\Mail\Mail;
$sendgrid = new \SendGrid('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'); // Replace with your actual SendGrid API key

$usersFile = 'users.json';
$passwordResetTokensFile = 'password_reset_tokens.json';
$whitelistFile = 'whitelist.json';

$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) ?? [] : [];
$passwordResetTokens = file_exists($passwordResetTokensFile) ? json_decode(file_get_contents($passwordResetTokensFile), true) ?? [] : [];
$whitelist = file_exists($whitelistFile) ? json_decode(file_get_contents($whitelistFile), true) ?? [] : [];

// Add user count to the users data
$users['metadata'] = [
    'total_users' => count($users)
];

// Save back to file if needed
file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

// Enkripsi
$key = '83929292922';
$method = 'AES-256-CBC';
$iv = '1234567890123456';
$hmacKey = '01100001';

// Google OAuth Configuration
$googleClient = new Google_Client();
$googleClient->setClientId('62521056555-humtm3rt960qmrm9el4o5lg1q3o5n95i.apps.googleusercontent.com');
$googleClient->setClientSecret('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');
$googleClient->setRedirectUri('https://api.aryastore.biz.id/google-callback.php');
$googleClient->addScope('email');
$googleClient->addScope('profile');

// GitHub OAuth Configuration
$githubClientId = 'Ov23lipq5xr7NVyJBhVl';
$githubClientSecret = '7b2e2477e1328ae6f45a0c415975619c099c4f7a';
$githubRedirectUri = 'https://api.aryastore.biz.id/?page=github-callback';


function encrypt($data, $key, $method, $iv, $hmacKey) {
    $encrypted = openssl_encrypt($data, $method, $key, 0, $iv);
    $hmac = hash_hmac('sha256', $encrypted, $hmacKey);
    return base64_encode($hmac . ':' . $encrypted);
}

function decrypt($data, $key, $method, $iv, $hmacKey) {
    $decoded = base64_decode($data);
    if ($decoded === false || strpos($decoded, ':') === false) return false;
    list($hmac, $encrypted) = explode(':', $decoded, 2);
    $validHmac = hash_hmac('sha256', $encrypted, $hmacKey);
    if (!hash_equals($hmac, $validHmac)) return false;
    return openssl_decrypt($encrypted, $method, $key, 0, $iv);
}

function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}


// User Registration Handler
if ($page === 'register' && isset($_POST['register'])) {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format!";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = "Username can only contain letters, numbers, and underscores!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } elseif (isset($users[$email])) {
        $error = "Email already registered!";
    } elseif (in_array(strtolower($username), array_map('strtolower', array_column($users, 'username')))) {
        $error = "Username already registered!";
    } else {
        // Generate verification token
        $verificationToken = bin2hex(random_bytes(32));
        $verificationExpiry = date('Y-m-d H:i:s', time() + 86400); // 24 hours expiry

        // Register new user (unverified)
        $users[$email] = [
            'username' => $username,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'api_keys' => [],
            'created_at' => date('Y-m-d H:i:s'),
            'auth_provider' => 'local',
            'email_verified' => false,
            'verification_token' => $verificationToken,
            'verification_expiry' => $verificationExpiry
        ];
        file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

        // Send Verification Email
$verificationLink = "https://api.aryastore.biz.id/?page=verify&token=$verificationToken&email=" . urlencode($email);
$email_content = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: auto; background-color: #f4f4f9; padding: 20px; border: 1px solid #ddd; border-radius: 10px;'>
        <h2 style='text-align: center; color: #333;'>Welcome to AryaStore!</h2>
        <p style='color: #555;'>Hi {$username},</p>
        <p style='color: #555; line-height: 1.6;'>We are excited to have you onboard. To complete your registration and start using our services, please confirm your email address by clicking the button below:</p>
        <div style='text-align: center; margin: 20px 0;'>
            <a href='{$verificationLink}' style='text-decoration: none;'>
                <button style='background-color: #4CAF50; color: #ffffff; padding: 12px 25px; font-size: 16px; border: none; border-radius: 5px; cursor: pointer;'>
                    Verify Your Email
                </button>
            </a>
        </div>
        <p style='color: #555; line-height: 1.6;'>If the button above does not work, you can also verify your email using the link below:</p>
        <p style='word-wrap: break-word; color: #007bff;'><a href='{$verificationLink}' style='color: #007bff;'>{$verificationLink}</a></p>
        <p style='color: #777; font-size: 14px;'>This link will expire in 24 hours. If you did not request this, please ignore this email.</p>
        <hr style='border: none; border-top: 1px solid #ddd; margin: 20px 0;'>
        <p style='text-align: center; color: #777; font-size: 12px;'>Need help? Visit our <a href='https://api.aryastore.biz.id/' style='color: #007bff;'>Support Center</a>.<br>Best regards,<br>AryaStore Team</p>
    </div>
";

        try {
            $emailMessage = new \SendGrid\Mail\Mail();
            $emailMessage->setFrom("noreplaybetapi@gmail.com", "Your App Name");
            $emailMessage->setSubject("Verify Your Email Address");
            $emailMessage->addTo($email, $username);
            $emailMessage->addContent("text/html", $email_content);
            $response = $sendgrid->send($emailMessage);

            if ($response->statusCode() >= 400) {
                $error = "Failed to send verification email. Please try again.";
                // Remove the unverified user if email sending fails
                unset($users[$email]);
                file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
            } else {
                // Set temporary session (unverified user)
                $_SESSION['unverified_user'] = [
                    'email' => $email,
                    'username' => $username
                ];

                header('Location: ?page=verify-pending');
                exit();
            }
        } catch (Exception $e) {
            $error = "An error occurred while sending the verification email.";
            error_log('SendGrid error: ' . $e->getMessage());

            // Remove the unverified user if email sending fails
            unset($users[$email]);
            file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
        }
    }
}

// Display error message if registration fails
if (isset($error)) {
    echo "<div class='alert alert-danger'>$error</div>";
}


// Email Verification Handler
// Email Verification Handler
if ($page === 'verify' && isset($_GET['token']) && isset($_GET['email'])) {
    $token = sanitize($_GET['token']);
    $email = sanitize($_GET['email']);
    
    if (isset($users[$email])) {
        $user = $users[$email];
        
        // Check if token is valid and not expired
        if ($user['verification_token'] === $token && strtotime($user['verification_expiry']) > time()) {
            // Mark email as verified
            $users[$email]['email_verified'] = true;
            unset($users[$email]['verification_token'], $users[$email]['verification_expiry']);
            file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
            
            // Set user session
            $_SESSION['user'] = $users[$email];
            unset($_SESSION['unverified_user']);
            
            // Redirect to verify-pending with success message
            header('Location: ?page=verify-pending&success=' . urlencode("Your email has been successfully verified."));
            exit();
        } else {
            // Redirect to verify-pending with error message
            header('Location: ?page=verify-pending&error=' . urlencode("Invalid or expired verification link."));
            exit();
        }
    } else {
        // Redirect to verify-pending with error message
        header('Location: ?page=verify-pending&error=' . urlencode("User not found."));
        exit();
    }
}







// Login process
if ($page === 'login' && isset($_POST['login'])) {
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Email and password are required!";
    } elseif (!isset($users[$email]) || !password_verify($password, $users[$email]['password']) || $users[$email]['auth_provider'] !== 'local') {
        $error = "Invalid email or password!";
    } else {
        $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
        setcookie('user_data', $encryptedUser, time() + 3600, "/", "", isset($_SERVER['HTTPS']), true);
        $_SESSION['user'] = $users[$email];
        header('Location: ?page=home');
        exit();
    }
}



       // Password Reset Request Handler
if ($page === 'forgot-password' && isset($_POST['request_reset'])) {
    $email = sanitize($_POST['email']);

    if (empty($email)) {
        $error = "Email is required!";
    } elseif (!isset($users[$email])) {
        $success = "If an account exists with this email, a reset link will be sent.";
    } else {
        $token = bin2hex(random_bytes(32));
        $expires = time() + 120;
        $passwordResetTokens[$email] = ['token' => $token, 'expires' => $expires];
        file_put_contents($passwordResetTokensFile, json_encode($passwordResetTokens, JSON_PRETTY_PRINT));

        $resetLink = "https://api.aryastore.biz.id/?page=reset-password&email=" . urlencode($email) . "&token=$token";

        $emailObj = new Mail();
        $emailObj->setFrom("noreplaybetapi@gmail.com", "AryaStore Support");
        $emailObj->setSubject("Password Reset Request - AryaStore");
        $emailObj->addTo($email);

        $emailContent = <<<HTML
<div style="font-family: 'Helvetica Neue', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff; border: 1px solid #e0e0e0; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    <div style="background: linear-gradient(135deg, #4CAF50, #45a049); padding: 20px; text-align: center;">
        <img src="https://api.aryastore.biz.id/logo/logo.jpg" alt="AryaStore Logo" style="max-width: 150px; margin-bottom: 10px;">
        <h2 style="color: #ffffff; margin: 0; font-size: 24px;">Password Reset Request</h2>
    </div>
    <div style="padding: 30px;">
        <p style="color: #333; font-size: 16px; line-height: 1.6;">Hello <strong>{$users[$email]['username']}</strong>,</p>
        <p style="color: #333; font-size: 16px; line-height: 1.6;">We received a request to reset your AryaStore account password. Click the button below to set a new password:</p>
        <div style="text-align: center; margin: 30px 0;">
            <a href="$resetLink" style="background-color: #4CAF50; color: #ffffff; padding: 14px 30px; text-decoration: none; font-size: 16px; font-weight: 600; border-radius: 8px; display: inline-block; transition: background-color 0.3s;">Reset Your Password</a>
        </div>
        <p style="color: #666; font-size: 14px; line-height: 1.6;">This link will expire in <strong>1 hour</strong> for your security.</p>
        <p style="color: #666; font-size: 14px; line-height: 1.6;">If you didnâ€™t request a password reset, please ignore this email or contact our support team.</p>
    </div>
    <div style="background: #f8f8f8; padding: 20px; text-align: center; font-size: 12px; color: #888; border-top: 1px solid #e0e0e0;">
        <p style="margin: 0;">AryaStore Support Team</p>
        <p style="margin: 8px 0;">
            <a href="https://aryastore.biz.id" style="color: #4CAF50; text-decoration: none;">Visit Our Website</a> | 
            <a href="mailto:support@aryastore.biz.id" style="color: #4CAF50; text-decoration: none;">Contact Support</a>
        </p>
        <p style="margin: 0;">Â© 2025 AryaStore. All rights reserved.</p>
    </div>
</div>
HTML;

        $emailObj->addContent("text/html", $emailContent);

        try {
            $response = $sendgrid->send($emailObj);
            $success = ($response->statusCode() >= 200 && $response->statusCode() < 300) ? "Password reset link has been sent to your email." : "Failed to send reset email. Please try again later.";
        } catch (Exception $e) {
            $error = "Failed to send reset email: " . $e->getMessage();
        }
    }
}

 if ($page === 'reset-password' && isset($_POST['reset_password'])) {
        $email = sanitize($_GET['email'] ?? '');
        $token = sanitize($_GET['token'] ?? '');
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        if (empty($newPassword) || empty($confirmPassword)) {
            $error = "Both fields are required!";
        } elseif ($newPassword !== $confirmPassword) {
            $error = "Passwords do not match!";
        } elseif (strlen($newPassword) < 6) {
            $error = "Password must be at least 6 characters!";
        } elseif (!isset($passwordResetTokens[$email]) || $passwordResetTokens[$email]['token'] !== $token || $passwordResetTokens[$email]['expires'] < time()) {
            $error = "Invalid or expired token!";
        } elseif (!isset($users[$email])) {
            $error = "User not found!";
        } else {
            $users[$email]['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
            unset($passwordResetTokens[$email]);
            file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
            file_put_contents($passwordResetTokensFile, json_encode($passwordResetTokens, JSON_PRETTY_PRINT));
            $success = "Password updated. <a href='?page=login'>Login</a>";
        }
    }



if ($page === 'home' && isset($_POST['generate']) && isset($_SESSION['user'])) {
        $keyName = sanitize($_POST['key_name'] ?? 'Default');
        $email = $_SESSION['user']['email'];
        $existingKeys = $users[$email]['api_keys'] ?? [];

        // Validasi jumlah maksimum key per user (maksimal 2)
        if (count($existingKeys) >= 2) {
            $error = "You have reached the maximum number of API keys (2).";
        } else {
            // Validasi duplikat nama key (case-sensitive)
            $duplicateKey = false;
            foreach ($existingKeys as $key => $info) {
                if ($info['name'] === $keyName) {
                    $duplicateKey = $info['name'];
                    break;
                }
            }

            if ($duplicateKey) {
                $error = "An API key named '{$duplicateKey}' already exists. Please choose a different name.";
            } else {
                $apikey = "API-" . bin2hex(random_bytes(8));
                $users[$email]['api_keys'][$apikey] = [
                    'name' => $keyName,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
                $_SESSION['user'] = $users[$email];
                $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
                $success = "API key generated!";
            }
        }
    }

    // Handle API Key Deletion
    if ($page === 'home' && isset($_POST['delete']) && isset($_POST['delete_key'], $_SESSION['user'])) {
        $email = $_SESSION['user']['email'];
        $deleteKey = $_POST['delete_key'];

        // Pastikan key ada dalam daftar keys user
        if (isset($users[$email]['api_keys'][$deleteKey])) {
            unset($users[$email]['api_keys'][$deleteKey]);
            file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
            $_SESSION['user'] = $users[$email];
            $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
            setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
            $success = "API key deleted.";
        } else {
            $error = "API key not found.";
        }
    }

    if ($page === 'home' && isset($_POST['add_ip']) && isset($_SESSION['user'])) {
        $newIp = sanitize($_POST['ip']);
        $email = $_SESSION['user']['email'];
        if (filter_var($newIp, FILTER_VALIDATE_IP)) {
            $whitelist[$email][] = $newIp;
            $whitelist[$email] = array_unique($whitelist[$email]);
            file_put_contents($whitelistFile, json_encode($whitelist, JSON_PRETTY_PRINT));
            $success = "IP $newIp added to whitelist.";
        } else {
            $error = "Invalid IP address.";
        }
    }

// Handle Google OAuth Callback
if ($page === 'google-callback') {
    if (isset($_GET['code'])) {
        $token = $googleClient->fetchAccessTokenWithAuthCode($_GET['code']);
        if (!isset($token['error'])) {
            $googleClient->setAccessToken($token['access_token']);
            $googleService = new Google_Service_Oauth2($googleClient);
            $userInfo = $googleService->userinfo->get();
            $email = $userInfo->email;
            $username = $userInfo->name ?: 'Google User';

            if (!isset($users[$email])) {
                $users[$email] = [
                    'username' => $username,
                    'email' => $email,
                    'password' => null,
                    'api_keys' => [],
                    'created_at' => date('Y-m-d H:i:s'),
                    'auth_provider' => 'google'
                ];
                file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
            } elseif ($users[$email]['auth_provider'] !== 'google') {
                $error = "This email is registered with another provider.";
                header('Location: ?page=login&error=' . urlencode($error));
                exit();
            }

            $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
            setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
            $_SESSION['user'] = $users[$email];
            header('Location: ?page=home');
            exit();
        } else {
            $error = "Google authentication failed.";
            header('Location: ?page=login&error=' . urlencode($error));
            exit();
        }
    }
}

// Handle GitHub OAuth Callback
if ($page === 'github-callback') {
    if (isset($_GET['code'])) {
        $tokenUrl = 'https://github.com/login/oauth/access_token';
        $params = [
            'client_id' => $githubClientId,
            'client_secret' => $githubClientSecret,
            'code' => $_GET['code'],
            'redirect_uri' => $githubRedirectUri
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $tokenUrl);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
        $response = curl_exec($ch);
        curl_close($ch);

        $tokenData = json_decode($response, true);

        if (isset($tokenData['access_token'])) {
            $userUrl = 'https://api.github.com/user';
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $userUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $tokenData['access_token'],
                'Accept: application/vnd.github.v3+json',
                'User-Agent: PHP-App'
            ]);
            $userResponse = curl_exec($ch);
            curl_close($ch);

            $userInfo = json_decode($userResponse, true);

            if (isset($userInfo['login'])) {
                $email = $userInfo['email'] ?: ($userInfo['login'] . '@github.com');
                $username = $userInfo['name'] ?: $userInfo['login'];

                if (!isset($users[$email])) {
                    $users[$email] = [
                        'username' => $username,
                        'email' => $email,
                        'password' => null,
                        'api_keys' => [],
                        'created_at' => date('Y-m-d H:i:s'),
                        'auth_provider' => 'github'
                    ];
                    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
                } elseif ($users[$email]['auth_provider'] !== 'github') {
                    $error = "This email is registered with another provider.";
                    header('Location: ?page=login&error=' . urlencode($error));
                    exit();
                }

                $encryptedUser = encrypt(json_encode($users[$email]), $key, $method, $iv, $hmacKey);
                setcookie('user_data', $encryptedUser, time() + 3600, "/", ".aryastore.biz.id", true, true);
                $_SESSION['user'] = $users[$email];
                header('Location: ?page=home');
                exit();
            } else {
                $error = "Failed to retrieve GitHub user information.";
                header('Location: ?page=login&error=' . urlencode($error));
                exit();
            }
        } else {
            $error = "GitHub authentication failed.";
            header('Location: ?page=login&error=' . urlencode($error));
            exit();
        }
    }
}


// Cek login dari cookie
if (isset($_COOKIE['user_data'])) {
    $decryptedUser = decrypt($_COOKIE['user_data'], $key, $method, $iv, $hmacKey);
    if ($decryptedUser) {
        $_SESSION['user'] = json_decode($decryptedUser, true);
    }
}

$loggedIn = isset($_SESSION['user']);

// Define API endpoints
// Define API endpoints
$apiEndpoints = [
    'weather' => [
        'category' => 'Information',
        'description' => 'Get weather data for a city',
        'icon' => 'cloud-sun',
        'params' => 'apikey (required), city (required)',
        'requires_input' => true,
        'input_label' => 'City Name',
        'input_placeholder' => 'e.g., Jakarta, London, New York'
    ],
    'joke' => [
        'category' => 'Fun',
        'description' => 'Get a random joke',
        'icon' => 'laugh-squint',
        'params' => 'apikey (required)',
        'requires_input' => false
    ],
    'tiktok' => [
        'category' => 'Downloader',
        'description' => 'Download TikTok video without watermark',
        'icon' => 'video',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'TikTok URL',
        'input_placeholder' => 'https://www.tiktok.com/@username/video/123456789'
    ],
    'brat' => [
        'category' => 'Generator',
        'description' => 'Generate video brat from text',
        'icon' => 'film',
        'params' => 'apikey (required), text (required), isVideo (optional), delay (optional)',
        'requires_input' => true,
        'input_label' => 'Text Input',
        'input_placeholder' => 'Enter your text here',
        'additional_params' => [
            'isVideo' => 'true or false (default: false)',
            'delay' => 'Animation delay in milliseconds (default: 500)'
        ]
    ],
    'twitter' => [
        'category' => 'Downloader',
        'description' => 'Download Twitter video or media by URL',
        'icon' => 'twitter',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'Twitter URL',
        'input_placeholder' => 'https://twitter.com/username/status/123456789'
    ],
    'terabox' => [
        'category' => 'Downloader',
        'description' => 'Download file from Terabox',
        'icon' => 'cloud-download-alt',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'Terabox URL',
        'input_placeholder' => 'https://www.terabox.com/sharing/link?surl=abcdefg'
    ],
    'mediafire' => [
        'category' => 'Downloader',
        'description' => 'Download file from MediaFire',
        'icon' => 'file-download',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'MediaFire URL',
        'input_placeholder' => 'https://www.mediafire.com/file/abcdefg'
    ],
    'deepseek' => [
        'category' => 'AI',
        'description' => 'Access the Deepseek AI API',
        'icon' => 'robot',
        'params' => 'apikey (required), content (required)',
        'requires_input' => true,
        'input_label' => 'Prompt',
        'input_placeholder' => 'What is the meaning of life?'
    ],
    'spotify' => [
        'category' => 'Music',
        'description' => 'Spotify search track info or title',
        'icon' => 'music',
        'params' => 'apikey (required), query (required)',
        'requires_input' => true,
        'input_label' => 'Search Query',
        'input_placeholder' => 'Song name or artist'
    ],
    'spotifydl' => [
        'category' => 'Music',
        'description' => 'Download Spotify track by title or link',
        'icon' => 'music',
        'params' => 'apikey (required), query (required)',
        'requires_input' => true,
        'input_label' => 'Track URL or Name',
        'input_placeholder' => 'https://open.spotify.com/track/... or song name'
    ],
    'hd' => [
        'category' => 'Downloader',
        'description' => 'Download or convert video to HD quality',
        'icon' => 'hd',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'Video URL',
        'input_placeholder' => 'https://www.youtube.com/watch?v=...'
    ],
    'infogempa' => [
        'category' => 'Information',
        'description' => 'Get the latest earthquake information from BMKG',
        'icon' => 'exclamation-triangle',
        'params' => 'apikey (required)',
        'requires_input' => false
    ],
    'claudeai' => [
        'category' => 'AI',
        'description' => 'Chat with Claude AI using text prompt',
        'icon' => 'comments',
        'params' => 'apikey (required), prompt (required)',
        'requires_input' => true,
        'input_label' => 'Message',
        'input_placeholder' => 'What would you like to ask?'
    ],
    'runtime' => [
        'category' => 'Tools',
        'description' => 'Get the current server runtime',
        'icon' => 'clock',
        'params' => 'apikey (required)',
        'requires_input' => false
    ],
    'pinterest' => [
        'category' => 'Downloader',
        'description' => 'Download images or videos from Pinterest',
        'icon' => 'pinterest',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'Pinterest URL',
        'input_placeholder' => 'https://www.pinterest.com/pin/123456789'
    ],
    'github' => [
        'category' => 'Search',
        'description' => 'Search GitHub repositories or user information',
        'icon' => 'github',
        'params' => 'apikey (required), query (required), type (optional: users/repos)',
        'requires_input' => true,
        'input_label' => 'Search Query',
        'input_placeholder' => 'Repository name or username',
        'additional_params' => [
            'type' => 'users or repos (default: repos)'
        ]
    ],
    'ytmp3' => [
        'category' => 'Downloader',
        'description' => 'Download YouTube video as MP3 audio',
        'icon' => 'music',
        'params' => 'apikey (required), url (required)',
        'requires_input' => true,
        'input_label' => 'YouTube URL',
        'input_placeholder' => 'https://www.youtube.com/watch?v=...'
    ],
    'ssweb' => [
        'category' => 'Tools',
        'description' => 'Take website screenshots',
        'icon' => 'camera',
        'params' => 'apikey (required), url (required), theme (optional), device (optional)',
        'requires_input' => true,
        'input_label' => 'Website URL',
        'input_placeholder' => 'https://example.com',
        'additional_params' => [
            'theme' => 'light or dark (default: light)',
            'device' => 'desktop or mobile (default: desktop)'
        ]
    ],
    'cekapikey' => [
        'category' => 'Tools',
        'description' => 'Check the validity and status of an API key',
        'icon' => 'key',
        'params' => 'apikey (required)',
        'requires_input' => true,
        'input_label' => 'API Key',
        'input_placeholder' => 'Enter your API key'
    ]
];

// Updated category icons with the new 'Search' category
$categoryIcons = [
    'Information' => 'info-circle',
    'Fun' => 'smile',
    'Downloader' => 'download',
    'AI' => 'brain',
    'Music' => 'headphones',
    'Tools' => 'tools',
    'Search' => 'search',
    'Generator' => 'film'
];

// Categorize endpoints
$categories = [];
foreach ($apiEndpoints as $endpoint => $data) {
    $categories[$data['category']][] = [
        'endpoint' => $endpoint,
        'data' => $data,
        'category_icon' => $categoryIcons[$data['category']] ?? 'question-circle'
    ];
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="google-site-verification" content="wftVB1A-HjA7S96f81oRs8dkZ5S9UDoBSLRE0Vlz7-c" />

  <!-- Primary Meta Tags for SEO -->
  <title>BetaAPI - Free, Secure, and Fast API Service</title>
  <meta name="description" content="BetaAPI offers free, secure, and fast API services for developers. Start building with our powerful API today.">
  <meta name="keywords" content="API, Free API, Secure API, BetaAPI, API Service, Developer API, Fast API">
  <meta name="author" content="Aryastore">
  <meta name="robots" content="index, follow">
  <meta name="language" content="English">

  <!-- Open Graph Meta Tags for Social Media -->
  <meta property="og:title" content="BetaAPI - Free, Secure, and Fast API Service">
  <meta property="og:description" content="BetaAPI offers free, secure, and fast API services for developers. Start building with our powerful API today.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://api.aryastore.biz.id/">
  <meta property="og:image" content="https://file.aryastore.biz.id/uploads/682b11dfbac4d.jpg">
  <meta property="og:site_name" content="BetaAPI">
  <meta property="og:locale" content="en_US">

  <!-- Twitter Card Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="BetaAPI - Free, Secure, and Fast API Service">
  <meta name="twitter:description" content="BetaAPI offers free, secure, and fast API services for developers. Start building with our powerful API today.">
  <meta name="twitter:image" content="https://file.aryastore.biz.id/uploads/682b11dfbac4d.jpg">
  <meta name="twitter:site" content="@YourTwitterHandle">
  <meta name="twitter:creator" content="@YourTwitterHandle">

  <!-- Canonical URL -->
  <link rel="canonical" href="https://api.aryastore.biz.id/" />

  <!-- Sitemap Reference -->
  <link rel="sitemap" type="application/xml" title="Sitemap" href="https://api.aryastore.biz.id/sitemap.xml" />

  <!-- Favicon -->
  <link rel="icon" href="https://file.aryastore.biz.id/uploads/682b11dfbac4d.jpg" type="image/x-icon">

  <!-- CSS & JS Libraries -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    /* Import Inter font with additional weights */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600;700;800&display=swap');  
  /* Global styles */
  body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background-color: #f9fafb;
    color: #1f2937;
    margin: 0;
    line-height: 1.6;
    animation: fadeIn 0.8s ease-in-out;
  }

  /* Keyframes for animations */
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes slideUp {
    from { transform: translateY(20px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }

  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }

  @keyframes scaleIn {
    from { transform: scale(0.95); }
    to { transform: scale(1); }
  }

  /* Gradient text for branding */
  .brand-text {
    background: linear-gradient(to right, #4f46e5, #06b6d4);
    background-clip: text;
    -webkit-background-clip: text;
    color: transparent;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
    letter-spacing: -0.025em;
    animation: fadeIn 1s ease-in-out;
  }

  /* Gradient background for sections */
  .gradient-bg {
    background: linear-gradient(135deg, #e5e7eb 0%, #a5b4fc 100%);
    border-radius: 12px;
    padding: 24px;
    animation: slideUp 0.6s ease-out;
  }

  /* Card hover effect with animation */
  .card-hover {
    background: #ffffff;
    border-radius: 12px;
    padding: 20px;
    transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
    position: relative;
    overflow: hidden;
    animation: slideUp 0.8s ease-out both;
  }
  .card-hover:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 12px 24px -6px rgba(0, 0, 0, 0.15);
    background: #f8fafc;
  }

  /* API endpoint styling */
  .api-endpoint {
    background: #f1f5f9;
    border-left: 4px solid #3b82f6;
    border-radius: 8px;
    padding: 16px;
    margin-bottom: 12px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 0.95rem;
    animation: fadeIn 1s ease-in-out;
  }

  /* API link with scale animation */
  .api-link {
    display: inline-block;
    padding: 8px 12px;
    border-radius: 6px;
    background: #eff6ff;
    color: #1e40af;
    font-weight: 500;
    text-decoration: none;
    transition: background 0.2s ease, transform 0.2s ease, color 0.2s ease;
    cursor: pointer;
    animation: scaleIn 0.5s ease-out;
  }
  .api-link:hover {
    background: #dbeafe;
    color: #1e3a8a;
    transform: translateX(4px) scale(1.05);
  }

  /* Image preview styling */
  #apiImagePreview {
    max-width: 100%;
    max-height: 450px;
    border-radius: 10px;
    margin-top: 16px;
    display: none;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    animation: fadeIn 0.6s ease-in-out;
  }

  /* Modal styling for input */
  #inputModal .modal-dialog {
    max-width: 550px;
    margin: 1.75rem auto;
    animation: slideUp 0.5s ease-out;
  }
  #inputModal .modal-content {
    border-radius: 12px;
    border: none;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    background: #ffffff;
  }
  #inputModal .modal-header {
    border-bottom: none;
    padding: 20px 24px;
  }
  #inputModal .modal-body {
    padding: 0 24px 24px;
  }
  #inputModal .modal-footer {
    border-top: none;
    padding: 16px 24px;
  }

  /* Button styling with pulse animation */
  .btn-primary {
    background: linear-gradient(to right, #4f46e5, #06b6d4);
    border: none;
    border-radius: 8px;
    padding: 12px 24px;
    font-weight: 600;
    color: #ffffff;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    animation: pulse 2s ease-in-out infinite;
  }
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
    animation-play-state: paused; /* Pause pulse on hover */
  }

  /* Responsiveness */
  @media (max-width: 768px) {
    body {
      padding: 0 16px;
    }
    .gradient-bg {
      padding: 16px;
    }
    .card-hover {
      margin-bottom: 24px;
      padding: 16px;
      animation-delay: 0.2s; /* Stagger animation for smaller screens */
    }
    .api-endpoint {
      padding: 12px;
      font-size: 0.9rem;
    }
    .api-link {
      font-size: 0.875rem;
      padding: 6px 10px;
    }
    #inputModal .modal-dialog {
      max-width: 90%;
      margin: 1rem auto;
    }
  }

  @media (max-width: 480px) {
    .brand-text {
      font-size: 1.25rem;
    }
    .card-hover {
      padding: 12px;
    }
    .api-link {
      font-size: 0.75rem;
      padding: 6px 8px;
    }
    .api-endpoint {
      font-size: 0.85rem;
    }
    .btn-primary {
      padding: 10px 16px;
      font-size: 0.875rem;
    }
  }
</style>


</head>
<body class="gradient-bg min-h-screen flex flex-col">

<?php if ($page !== 'landing'): ?>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm py-3 sticky top-0 z-50">
  <div class="container">
    <a class="navbar-brand text-2xl font-bold brand-text flex items-center" href="?page=landing">
      <i class="fas fa-bolt text-blue-500 mr-2"></i> alya-api
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto gap-3">
        <li class="nav-item">
          <a class="nav-link hover:text-blue-600 transition" href="?page=home"><i class="fas fa-home mr-1"></i> Home</a>
        </li>
        <?php if ($loggedIn): ?>
          <li class="nav-item">
            <a class="nav-link hover:text-blue-600 transition" href="?page=profile"><i class="fas fa-user mr-1"></i> <?= htmlspecialchars($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8') ?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link hover:text-blue-600 transition" href="?page=logout"><i class="fas fa-sign-out-alt mr-1"></i> Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link hover:text-blue-600 transition" href="?page=register"><i class="fas fa-user-plus mr-1"></i> Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link hover:text-blue-600 transition" href="?page=login"><i class="fas fa-sign-in-alt mr-1"></i> Login</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<?php endif; ?>

<?php if ($page === 'verify-pending'): ?>
<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
      <div class="card border-0 shadow-lg rounded-3 overflow-hidden">
        <!-- Card Header -->
        <div class="card-header bg-gradient-primary text-white py-4">
          <div class="d-flex justify-content-center">
            <i class="fas fa-envelope-circle-check fa-3x"></i>
          </div>
          <h3 class="text-center mt-3 mb-0">Email Verification</h3>
        </div>
        
        <!-- Card Body -->
        <div class="card-body p-5">
          <?php 
          // Check for error parameter in the URL
          if (isset($_GET['error']) && $_GET['error'] === 'Invalid or expired verification link') {
              $error = $_GET['error'];
          }
          ?>
          
          <?php if (isset($error)): ?>
            <!-- Error State -->
            <div class="text-center" style="color: black;">
              <div class="mb-4">
                <i class="fas fa-circle-exclamation fa-4x text-danger"></i>
              </div>
              <h4 class="text-danger mb-3" style="color: black !important;">Verification Failed</h4>
              <div class="alert alert-danger rounded-2" style="color: black;"><?= htmlspecialchars($error) ?></div>
              <div class="alert alert-info rounded-2 mt-3" style="color: black;">
                <i class="fas fa-info-circle me-2"></i>
                Please check your email and click the verification link we sent you.
              </div>
              <a href="?page=verify&token=<?= urlencode($_GET['token'] ?? '') ?>&email=<?= urlencode($_GET['email'] ?? '') ?>" 
                 class="btn btn-primary px-4 py-2 rounded-pill mt-3" style="color: black;">
                <i class="fas fa-rotate-right me-2"></i>Try Again
              </a>
            </div>
          
          <?php elseif (isset($success) || (isset($_GET['success']) && $_GET['success'] === 'Your email has been successfully verified.')): ?>
            <!-- Success State -->
            <div class="text-center">
              <div class="mb-4">
                <div class="position-relative d-inline-block">
                  <i class="fas fa-check-circle fa-4x text-success"></i>
                  <div class="position-absolute top-0 start-100 translate-middle p-2 bg-white rounded-circle shadow-sm">
                    <i class="fas fa-check text-success"></i>
                  </div>
                </div>
              </div>
              <h4 class="text-success mb-3">Verification Successful!</h4>
              <p class="text-muted">Your email address has been successfully verified.</p>
              
              <div class="d-inline-block bg-light rounded-3 p-3 mt-4 mb-3">
                <p class="mb-1">Redirecting to homepage in</p>
                <h2 class="text-primary mb-0" id="countdown">3</h2>
                <span class="text-muted small">seconds</span>
              </div>
              
              <div class="mt-4">
                <a href="?page=home" class="btn btn-outline-primary px-4 py-2 rounded-pill">
                  <i class="fas fa-home me-2"></i>Go Home Now
                </a>
              </div>
            </div>
            <script>
              let countdown = 3;
              const countdownElement = document.getElementById('countdown');
              const redirectInterval = setInterval(() => {
                countdown--;
                countdownElement.textContent = countdown;
                if (countdown <= 0) {
                  clearInterval(redirectInterval);
                  window.location.href = "?page=home";
                }
              }, 1000);
            </script>
          
          <?php else: ?>
            <!-- Loading/Verification Pending State -->
            <div class="text-center">
              <div class="mb-4">
                <div class="spinner-grow text-primary" style="width: 4rem; height: 4rem;" role="status">
                  <span class="visually-hidden">Loading...</span>
                </div>
              </div>
              <h4 class="text-primary mb-3">Check Your Email</h4>
              
              <div class="alert alert-info rounded-2">
                <div class="d-flex align-items-center">
                  <i class="fas fa-envelope-open-text fa-2x me-3"></i>
                  <div>
                    <p class="mb-1">We've sent a verification link to your email address.</p>
                    <p class="mb-0"><strong>Please check your inbox</strong> and click the link to verify your account.</p>
                  </div>
                </div>
              </div>
              
              <div class="mt-4 p-4 bg-light rounded-3">
                <h5 class="mb-3">Didn't receive the email?</h5>
                <ul class="list-unstyled text-start">
                  <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Check your spam/junk folder</li>
                  <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Make sure you entered the correct email</li>
                  <li class="mb-0"><i class="fas fa-check-circle text-success me-2"></i> Wait a few minutes and try again</li>
                </ul>
                
                <button class="btn btn-outline-secondary mt-3 px-4 py-2 rounded-pill">
                  <i class="fas fa-paper-plane me-2"></i>Resend Verification Email
                </button>
              </div>
              
              <div class="progress mt-4" style="height: 6px;">
                <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
              </div>
            </div>
          <?php endif; ?>
        </div>
        
        <!-- Card Footer -->
        <div class="card-footer bg-light text-center py-3">
          <small class="text-muted">Need help? <a href="?page=contact" class="text-decoration-none">Contact our support team</a></small>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($page === 'terms-of-service'): ?>
<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-md-10 col-lg-8">
      <div class="card border-0 shadow-lg rounded-3 overflow-hidden">
        <!-- Card Header -->
        <div class="card-header bg-gradient-primary text-white py-4">
          <h2 class="text-center mb-0">Terms of Service</h2>
        </div>
        
        <!-- Card Body -->
        <div class="card-body p-5">
          <div class="mb-5">
            <h4 class="mb-3">1. Acceptance of Terms</h4>
            <p>By accessing or using our services, you agree to be bound by these Terms of Service and our Privacy Policy. If you do not agree with any part of these terms, you may not use our services.</p>
          </div>
          
          <div class="mb-5">
            <h4 class="mb-3">2. Description of Service</h4>
            <p>We provide [brief description of your service]. The service may include web-based tools, mobile applications, and other related services.</p>
          </div>
          
          <div class="mb-5">
            <h4 class="mb-3">3. User Responsibilities</h4>
            <ul class="list-group list-group-flush mb-3">
              <li class="list-group-item bg-transparent">You are responsible for maintaining the confidentiality of your account information</li>
              <li class="list-group-item bg-transparent">You agree to use the service only for lawful purposes</li>
              <li class="list-group-item bg-transparent">You will not engage in any activity that interferes with or disrupts the service</li>
            </ul>
          </div>
          
          <div class="mb-5">
            <h4 class="mb-3">4. Intellectual Property</h4>
            <p>All content included on the service, such as text, graphics, logos, and software, is the property of [Your Company] or its content suppliers and protected by intellectual property laws.</p>
          </div>
          
          <div class="mb-5">
            <h4 class="mb-3">5. Limitation of Liability</h4>
            <p>[Your Company] shall not be liable for any indirect, incidental, special, consequential or punitive damages resulting from your use of or inability to use the service.</p>
          </div>
          
          <div class="mb-5">
            <h4 class="mb-3">6. Modifications to Terms</h4>
            <p>We reserve the right to modify these terms at any time. Your continued use of the service following any changes constitutes your acceptance of the new terms.</p>
          </div>
          
          <div class="alert alert-info mt-4">
            <i class="fas fa-info-circle me-2"></i>
            If you have any questions about these Terms of Service, please contact us at <a href="mailto:legal@yourcompany.com">legal@yourcompany.com</a>.
          </div>
        </div>
        
        <!-- Card Footer -->
        <div class="card-footer bg-light text-center py-3">
          <small class="text-muted">Last updated: <?= date('F j, Y') ?></small>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($page === 'jumlahuser'): ?>
    <?php
    // Initialize variables with empty arrays if not set
    $users = $users ?? [];
    $whitelist = $whitelist ?? [];
    $passwordResetTokens = $passwordResetTokens ?? [];
    
    // Configuration
    $growthPercentage = 10; // Example growth percentage
    date_default_timezone_set('UTC');
    
    // Helper calculations
    $totalUsers = count($users);
    $totalWhitelist = count($whitelist);
    $totalResets = count($passwordResetTokens);
    
    // Percentage calculations (with division by zero protection)
    $whitelistPercentage = $totalUsers ? ($totalWhitelist / $totalUsers * 100) : 0;
    $resetPercentage = $totalUsers ? ($totalResets / $totalUsers * 100) : 0;
    ?>
    
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <!-- Main Card -->
                <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                    
                    <!-- Card Header -->
                    <div class="card-header bg-gradient-primary-to-secondary text-white py-4 position-relative">
                        <div class="position-absolute top-0 end-0 p-3 opacity-25">
                            <i class="fas fa-users fa-3x" aria-hidden="true"></i>
                        </div>
                        <h2 class="text-center mb-0 fw-bold">User Statistics Dashboard</h2>
                        <p class="text-center mb-0 mt-2 opacity-75">Comprehensive overview of user data</p>
                    </div>
                    
                    <!-- Card Body -->
                    <div class="card-body p-4 p-md-5">
                        
                        <!-- Main User Count Section -->
                        <section class="mb-5 text-center position-relative">
                            <div class="position-absolute top-0 start-0 end-0 mt-n3">
                                <div class="d-flex justify-content-center">
                                    <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill">
                                        <i class="fas fa-chart-line me-2"></i> Live Data
                                    </span>
                                </div>
                            </div>
                            
                            <h4 class="mb-4 text-muted">Current User Count</h4>
                            <div class="display-3 fw-bold text-primary mb-3">
                                <?= number_format($totalUsers) ?>
                            </div>
                            <div class="d-flex justify-content-center align-items-center">
                                <span class="badge bg-success bg-opacity-10 text-success px-3 py-1 rounded-pill small">
                                    <i class="fas fa-arrow-up me-1"></i> 
                                    <?= number_format($growthPercentage, 1) ?>% from last month
                                </span>
                            </div>
                            <p class="text-muted mt-3">Total registered users in our system</p>
                        </section>
                        
                        <!-- Metrics Section -->
                        <section class="mb-5">
                            <h4 class="mb-4 text-center text-muted">Additional Metrics</h4>
                            
                            <div class="row g-4">
                                <!-- Whitelisted Users Card -->
                                <div class="col-md-6">
                                    <div class="card h-100 border-0 shadow-sm hover-shadow transition-all">
                                        <div class="card-body text-center p-4">
                                            <div class="icon-lg bg-primary bg-opacity-10 text-primary rounded-circle mb-3 mx-auto">
                                                <i class="fas fa-check-circle"></i>
                                            </div>
                                            <h5 class="text-muted mb-3">Whitelisted Users</h5>
                                            <div class="h2 fw-bold text-primary">
                                                <?= number_format($totalWhitelist) ?>
                                            </div>
                                            <div class="progress mt-3" style="height: 6px;">
                                                <div class="progress-bar bg-success" 
                                                     style="width: <?= min(100, $whitelistPercentage) ?>%"
                                                     aria-valuenow="<?= $totalWhitelist ?>"
                                                     aria-valuemin="0"
                                                     aria-valuemax="<?= $totalUsers ?>">
                                                </div>
                                            </div>
                                            <small class="text-muted mt-2 d-block">
                                                <?= number_format($whitelistPercentage, 1) ?>% of total users
                                            </small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Password Resets Card -->
                                <div class="col-md-6">
                                    <div class="card h-100 border-0 shadow-sm hover-shadow transition-all">
                                        <div class="card-body text-center p-4">
                                            <div class="icon-lg bg-warning bg-opacity-10 text-warning rounded-circle mb-3 mx-auto">
                                                <i class="fas fa-key"></i>
                                            </div>
                                            <h5 class="text-muted mb-3">Password Resets</h5>
                                            <div class="h2 fw-bold text-warning">
                                                <?= number_format($totalResets) ?>
                                            </div>
                                            <div class="progress mt-3" style="height: 6px;">
                                                <div class="progress-bar bg-warning"
                                                     style="width: <?= min(100, $resetPercentage) ?>%"
                                                     aria-valuenow="<?= $totalResets ?>"
                                                     aria-valuemin="0"
                                                     aria-valuemax="<?= $totalUsers ?>">
                                                </div>
                                            </div>
                                            <small class="text-muted mt-2 d-block">
                                                <?= number_format($resetPercentage, 1) ?>% reset rate
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        
                        <!-- Info Alert -->
                        <div class="alert alert-info bg-opacity-10 border-info border-start-0 border-end-0 border-5 rounded-3 mt-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle fa-2x text-info me-3"></i>
                                <div>
                                    <h5 class="alert-heading mb-1">Real-time Data</h5>
                                    <p class="mb-0 small">Statistics are updated continuously. Last refreshed: <?= date('H:i:s') ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Card Footer -->
                    <footer class="card-footer bg-light text-center py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <small class="text-muted">
                                <i class="fas fa-database me-1"></i> Data as of <?= date('F j, Y') ?>
                            </small>
                            <button class="btn btn-sm btn-outline-primary" onclick="location.reload()">
                                <i class="fas fa-sync-alt me-1"></i> Refresh Data
                            </button>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>






<!-- Content -->
<main class="flex-grow py-8">
  <div class="container px-4">
    <?php if (isset($error)): ?>
      <div class="alert alert-danger mb-4"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if (isset($success)): ?>
      <div class="alert alert-success mb-4"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($page === 'landing'): ?>
      <div class="text-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-3xl mx-auto">
          <h1 class="text-5xl md:text-6xl font-extrabold brand-text mb-6 leading-tight">
            Build Amazing Apps <br>With <span class="underline decoration-blue-400">ARYASTORE API</span>
          </h1>
          <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Free, powerful public APIs to accelerate your development. No credit card required.
          </p>
          <div class="flex flex-col sm:flex-row justify-center gap-4">
            <a href="<?= isset($_SESSION['user']) ? '?page=home' : '?page=login' ?>" class="btn btn-primary px-6 py-3 rounded-lg text-lg font-medium shadow-lg hover:shadow-xl transition">
              <i class="fas fa-rocket mr-2"></i> Get Started
            </a>
            <a href="#features" class="btn btn-outline-primary px-6 py-3 rounded-lg text-lg font-medium transition">
              <i class="fas fa-search mr-2"></i> Explore Features
            </a>
            <a href="?page=jumlahuser" class="btn btn-outline-info px-6 py-3 rounded-lg text-lg font-medium transition">
              <i class="fas fa-users mr-2"></i> User Stats
            </a>
          </div>
        </div>
      </div>

      <div id="features" class="py-16 bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm px-6 my-12">
        <div class="max-w-4xl mx-auto text-center mb-12">
          <h2 class="text-3xl font-bold text-gray-800 mb-4">Why Choose BetaAPI?</h2>
          <p class="text-lg text-gray-600">We provide everything you need to build your next great application</p>
        </div>
        
        <div class="grid md:grid-cols-3 gap-8">
          <div class="bg-white p-6 rounded-xl shadow-md card-hover">
            <div class="text-blue-500 text-3xl mb-4">
              <i class="fas fa-bolt"></i>
            </div>
            <h3 class="text-xl font-semibold mb-3">Lightning Fast</h3>
            <p class="text-gray-600">Our APIs respond in under 100ms, ensuring your apps stay snappy.</p>
          </div>
          
          <div class="bg-white p-6 rounded-xl shadow-md card-hover">
            <div class="text-blue-500 text-3xl mb-4">
              <i class="fas fa-shield-alt"></i>
            </div>
            <h3 class="text-xl font-semibold mb-3">Secure</h3>
            <p class="text-gray-600">Enterprise-grade security with API keys and rate limiting.</p>
          </div>
          
          <div class="bg-white p-6 rounded-xl shadow-md card-hover">
            <div class="text-blue-500 text-3xl mb-4">
              <i class="fas fa-infinity"></i>
            </div>
            <h3 class="text-xl font-semibold mb-3">Always Free</h3>
            <p class="text-gray-600">No hidden costs. Our basic tier remains free forever.</p>
          </div>
        </div>
      </div>

    <?php elseif ($page === 'home'): ?>
      <?php if (!$loggedIn): ?>
        <div class="text-center py-12">
          <h2 class="text-2xl font-bold mb-4">Please login to access the dashboard</h2>
          <a href="?page=login" class="btn btn-primary px-6 py-3">Login Now</a>
        </div>
      <?php else: ?>
        <div class="text-center mb-10">
          <h1 class="text-4xl font-extrabold brand-text mb-3">Welcome, <?= htmlspecialchars($_SESSION['user']['username']) ?></h1>
          <p class="text-xl text-gray-600">Manage your API integrations</p>
        </div>

<!-- API Key Generator -->
<div class="bg-white p-6 rounded-xl shadow-md mb-8 max-w-3xl mx-auto">
  <div class="flex items-center justify-between mb-4">
    <h2 class="text-2xl font-bold text-gray-800 flex items-center">
      <i class="fas fa-key text-blue-500 mr-3"></i> API Key Management
    </h2>
    <span class="badge bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
      <?= count($_SESSION['user']['api_keys'] ?? []) ?> Active Keys
    </span>
  </div>

  <form method="post" class="mb-4">
    <div class="flex flex-col sm:flex-row gap-4">
      <input type="text" class="form-control flex-grow" placeholder="Enter a name for your key (optional)" name="key_name">
      <button name="generate" class="btn btn-primary px-6 whitespace-nowrap">
        <i class="fas fa-plus-circle mr-2"></i> Generate Key
      </button>
    </div>
  </form>

<?php if (!empty($_SESSION['user']['api_keys'])): ?>
    <div class="mt-6">
      <h3 class="text-lg font-semibold mb-3">Your API Keys</h3>
      <div class="space-y-3">
        <?php foreach ($_SESSION['user']['api_keys'] as $key => $keyData): ?>
          <div class="bg-gray-50 p-4 rounded-lg flex justify-between items-center">
            <div>
              <div class="font-medium"><?= htmlspecialchars($keyData['name']) ?></div>
              <div class="text-sm text-gray-500 mt-1 font-mono break-all"><?= htmlspecialchars($key) ?></div>
              <div class="text-xs text-gray-400 mt-1">Created: <?= htmlspecialchars($keyData['created_at']) ?></div>
            </div>
            <div class="flex gap-2">
              <button class="btn btn-sm btn-outline-primary copy-btn" data-key="<?= htmlspecialchars($key) ?>">
                <i class="fas fa-copy mr-1"></i> Copy
              </button>
              <form method="post" onsubmit="return confirm('Are you sure you want to delete this API key?');">
                <input type="hidden" name="delete_key" value="<?= htmlspecialchars($key) ?>">
                <button type="submit" name="delete" class="btn btn-sm btn-outline-danger">
                  <i class="fas fa-trash mr-1"></i> Delete
                </button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="mt-6 text-center text-gray-500">You have no active API keys.</div>
  <?php endif; ?>
</div>



<!-- API List -->
<div class="mt-10">
  <h2 class="text-2xl font-bold text-gray-800 mb-4 flex items-center">
    <i class="fas fa-list text-blue-500 mr-3"></i> Available API Endpoints
  </h2>

  <!-- Loop through categories -->
  <?php foreach ($categories as $category => $endpoints): ?>
    <div class="mb-6">
      <h3 class="text-xl font-bold text-gray-800 flex items-center">
        <i class="fas fa-<?= $categoryIcons[$category] ?? 'question-circle' ?> text-blue-500 mr-3"></i>
        <?= ucfirst($category) ?>
      </h3>
      <div class="grid md:grid-cols-2 gap-6 mt-4">
        <!-- Loop through APIs under this category -->
        <?php foreach ($endpoints as $item): ?>
          <div class="p-5 rounded-xl shadow-sm bg-white border-l-4 border-blue-500 card-hover">
            <div class="flex items-center mb-2">
              <i class="fas fa-<?= $item['data']['icon'] ?> text-blue-500 text-xl mr-3"></i>
              <h3 class="text-xl font-semibold text-gray-800"><?= ucfirst($item['endpoint']) ?></h3>
            </div>
            <p class="text-gray-600 mb-2"><?= $item['data']['description'] ?></p>
            <p class="text-sm text-gray-500 mb-1"><strong>Category:</strong> <?= $item['data']['category'] ?? 'Uncategorized' ?></p>
            <p class="text-sm text-gray-500"><strong>Parameters:</strong> <?= $item['data']['params'] ?></p>
            <div class="text-sm mt-3 font-mono text-blue-600">
              <span class="text-gray-600">GET</span> /api.php?endpoint=<?= $item['endpoint'] ?>&apikey=...
            </div>
            <button onclick="prepareTestEndpoint('<?= $item['endpoint'] ?>', <?= isset($item['data']['requires_input']) ? 'true' : 'false' ?>)" class="btn btn-sm btn-outline-primary mt-3">
              <i class="fas fa-play mr-1"></i> Test Endpoint
            </button>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>


        <!-- Input Modal -->
        <div class="modal fade" id="inputModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="inputModalTitle">Enter Required Information</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form id="inputForm">
                  <input type="hidden" id="currentEndpoint">
                  <div class="mb-3">
                    <label id="inputLabel" class="form-label">Input</label>
                    <input type="text" id="endpointInput" class="form-control" placeholder="Enter value">
                    <small id="inputHelp" class="text-muted"></small>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="submitEndpointInput()">Submit</button>
              </div>
            </div>
          </div>
        </div>

        <!-- API Response Modal -->
        <div class="modal fade" id="apiResponseModal" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="modalEndpointTitle">API Response</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="mb-3">
                  <label class="form-label">Request URL</label>
                  <input type="text" id="requestUrl" class="form-control" readonly>
                </div>
                <div class="text-center mb-3">
                  <img id="apiImagePreview" class="mx-auto rounded-lg shadow-md" alt="API Image Response">
                </div>
                <div>
                  <label class="form-label">Response</label>
                  <pre class="bg-gray-800 text-gray-100 p-3 rounded" id="apiResponse"></pre>
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="copyApiUrl()">
                  <i class="fas fa-copy mr-1"></i> Copy URL
                </button>
              </div>
            </div>
          </div>
        </div>

     <script>
function prepareTestEndpoint(endpoint, requiresInput) {
  const apiKeys = <?= json_encode($_SESSION['user']['api_keys'] ?? []) ?>;
  if (Object.keys(apiKeys).length === 0) {
    alert('Please generate an API key first');
    return;
  }

  if (requiresInput && endpoint !== 'runtime') {
    const endpointData = <?= json_encode($apiEndpoints) ?>[endpoint];
    document.getElementById('currentEndpoint').value = endpoint;
    document.getElementById('inputModalTitle').textContent = `${endpoint.charAt(0).toUpperCase() + endpoint.slice(1)} API - Required Input`;

    if (endpoint === 'kecocokanpasangan') {
      document.getElementById('inputLabel').innerHTML = 'Nama 1 dan Nama 2 (pisahkan dengan koma, contoh: John, Jane)';
      document.getElementById('endpointInput').placeholder = 'Masukkan Nama1, Nama2';
    } else if (endpoint === 'artinama') {
      document.getElementById('inputLabel').innerHTML = 'Nama (Masukkan satu nama)';
      document.getElementById('endpointInput').placeholder = 'Masukkan Nama';
    } else if (endpoint === 'removebg') {
      document.getElementById('inputLabel').innerHTML = 'URL Gambar (Masukkan URL gambar untuk menghapus latar belakang)';
      document.getElementById('endpointInput').placeholder = 'Masukkan URL gambar';
    } else if (endpoint === 'github') {
      document.getElementById('inputLabel').innerHTML = 'GitHub URL (Masukkan URL GitHub Repo/File)';
      document.getElementById('endpointInput').placeholder = 'Contoh: https://github.com/user/repo';
    } else if (endpoint === 'pinterest') {
      document.getElementById('inputLabel').innerHTML = 'Search Pinterest (Enter keyword or phrase)';
      document.getElementById('endpointInput').placeholder = 'Search for images or content';
    } else if (endpoint === 'twitter') {
      document.getElementById('inputLabel').innerHTML = 'Twitter URL atau ID';
      document.getElementById('endpointInput').placeholder = 'Masukkan URL atau ID Tweet';
    } else if (endpoint === 'blackboxai') {
      document.getElementById('inputLabel').innerHTML = 'Prompt (Enter your question or request)';
      document.getElementById('endpointInput').placeholder = 'Type your prompt for Blackbox AI';
    } else if (endpoint === 'deepseek') {
      document.getElementById('inputLabel').innerHTML = 'Prompt (Enter your question or request)';
      document.getElementById('endpointInput').placeholder = 'Type your prompt for Deepseek';
    } else if (endpoint === 'claudeai') {
      document.getElementById('inputLabel').innerHTML = 'Prompt (Enter your question or request)';
      document.getElementById('endpointInput').placeholder = 'Type your prompt for Claude AI';
    } else if (endpoint === 'brat') {
      document.getElementById('inputLabel').innerHTML = 'Text to Analyze (Enter text for BRAT analysis)';
      document.getElementById('endpointInput').placeholder = 'Enter text to analyze';
    } else if (endpoint === 'ytmp3') {
      document.getElementById('inputLabel').innerHTML = 'YouTube URL (Masukkan URL video YouTube)';
      document.getElementById('endpointInput').placeholder = 'Contoh: https://youtube.com/watch?v=...';
    } else if (endpoint === 'ssweb') {
      document.getElementById('inputLabel').innerHTML = 'Website URL (Enter URL to capture screenshot)';
      document.getElementById('endpointInput').placeholder = 'https://example.com';
    } else {
      document.getElementById('inputLabel').textContent = endpointData.input_label || 'Input';
      document.getElementById('endpointInput').placeholder = endpointData.input_placeholder || 'Enter required value';
    }

    const inputModal = new bootstrap.Modal(document.getElementById('inputModal'));
    inputModal.show();
  } else {
    testEndpoint(endpoint);
  }
}

function submitEndpointInput() {
  const endpoint = document.getElementById('currentEndpoint').value;
  const inputValue = document.getElementById('endpointInput').value.trim();

  if (!inputValue) {
    alert('Please enter a value');
    return;
  }

  const inputModal = bootstrap.Modal.getInstance(document.getElementById('inputModal'));
  inputModal.hide();

  testEndpoint(endpoint, inputValue);
}

function testEndpoint(endpoint, inputValue = null) {
  const apiKeys = <?= json_encode($_SESSION['user']['api_keys'] ?? []) ?>;
  const apiKey = Object.keys(apiKeys)[0];
  let url = `/api.php?endpoint=${endpoint}&apikey=${apiKey}`;

  if (inputValue !== null) {
    if (endpoint === 'kecocokanpasangan') {
      const parts = inputValue.split(',');
      if (parts.length !== 2) {
        alert('Please enter two names separated by a comma, e.g., John, Jane');
        return;
      }
      const nama1 = parts[0].trim();
      const nama2 = parts[1].trim();
      url += `&nama1=${encodeURIComponent(nama1)}&nama2=${encodeURIComponent(nama2)}`;
    } else if (endpoint === 'artinama') {
      url += `&name=${encodeURIComponent(inputValue)}`;
    } else if (['removebg', 'github', 'spotifydl', 'twitter', 'ytmp3', 'tiktok', 'terabox', 'mediafire', 'ssweb'].includes(endpoint)) {
      url += `&url=${encodeURIComponent(inputValue)}`;
    } else if (endpoint === 'pinterest' || endpoint === 'spotify') {
      url += `&query=${encodeURIComponent(inputValue)}`;
    } else if (endpoint === 'blackboxai' || endpoint === 'brat') {
      url += `&text=${encodeURIComponent(inputValue)}`;
    } else if (endpoint === 'deepseek' || endpoint === 'claudeai') {
      url += `&prompt=${encodeURIComponent(inputValue)}`;
    } else if (endpoint === 'weather') {
      url += `&city=${encodeURIComponent(inputValue)}`;
    } else {
      url += `&url=${encodeURIComponent(inputValue)}`;
    }
  }

  // Add optional parameters for ssweb
  if (endpoint === 'ssweb') {
    const theme = document.getElementById('sswebTheme')?.value || 'light';
    const device = document.getElementById('sswebDevice')?.value || 'desktop';
    url += `&theme=${theme}&device=${device}`;
  }

  document.getElementById('requestUrl').value = url;
  document.getElementById('modalEndpointTitle').textContent = `${endpoint.charAt(0).toUpperCase() + endpoint.slice(1)} API Response`;
  document.getElementById('apiResponse').textContent = 'Loading...';
  document.getElementById('apiImagePreview').style.display = 'none';

  const modal = new bootstrap.Modal(document.getElementById('apiResponseModal'));
  modal.show();

  fetch(url)
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('image')) {
        return response.blob().then(blob => ({ isImage: true, data: blob }));
      }
      return response.text().then(text => ({ isImage: false, data: text }));
    })
    .then(({ isImage, data }) => {
      if (isImage) {
        const imageUrl = URL.createObjectURL(data);
        document.getElementById('apiImagePreview').src = imageUrl;
        document.getElementById('apiImagePreview').style.display = 'block';
        document.getElementById('apiResponse').textContent = 'Image response received (displayed above)';
      } else {
        try {
          const jsonData = JSON.parse(data);
          document.getElementById('apiResponse').textContent = JSON.stringify(jsonData, null, 2);

          // Handle cekapikey response to display apikey
          if (endpoint === 'cekapikey' && jsonData.apikey) {
            const apiKeyDisplay = document.createElement('div');
            apiKeyDisplay.innerHTML = `
              <div class="input-group mb-2">
                <input type="text" class="form-control" value="${jsonData.apikey}" readonly>
                <button class="btn btn-outline-secondary copy-api-btn" type="button" data-key="${jsonData.apikey}">
                  <i class="fas fa-copy mr-1"></i> Copy
                </button>
              </div>
            `;
            document.getElementById('apiResponse').prepend(apiKeyDisplay);
          }

          // Handle screenshot response
          if (endpoint === 'ssweb' && jsonData.image) {
            document.getElementById('apiImagePreview').src = jsonData.image;
            document.getElementById('apiImagePreview').style.display = 'block';
            document.getElementById('apiResponse').textContent = 'Screenshot generated successfully';
          } else if (jsonData.image && jsonData.image.startsWith('data:image/')) {
            document.getElementById('apiImagePreview').src = jsonData.image;
            document.getElementById('apiImagePreview').style.display = 'block';
            document.getElementById('apiResponse').textContent = 'Base64 image data received (displayed above)';
          }
        } catch (e) {
          document.getElementById('apiResponse').textContent = data;
          if (data.startsWith('data:image/')) {
            document.getElementById('apiImagePreview').src = data;
            document.getElementById('apiImagePreview').style.display = 'block';
            document.getElementById('apiResponse').textContent = 'Base64 image data received (displayed above)';
          }
        }
      }
    })
    .catch(error => {
      document.getElementById('apiResponse').textContent = `Error: ${error.message}`;
    });
}

function copyApiUrl() {
  const urlInput = document.getElementById('requestUrl');
  urlInput.select();
  try {
    document.execCommand('copy');
    alert('API URL copied to clipboard!');
  } catch (err) {
    alert('Failed to copy URL: ' + err.message);
  }
}

// Copy API key buttons
document.querySelectorAll('.copy-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    const key = this.getAttribute('data-key');
    if (navigator.clipboard) {
      navigator.clipboard.writeText(key).then(() => {
        this.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
        setTimeout(() => {
          this.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
        }, 2000);
      }).catch(err => {
        // Fallback for older browsers
        const tempInput = document.createElement('input');
        tempInput.value = key;
        document.body.appendChild(tempInput);
        tempInput.select();
        try {
          document.execCommand('copy');
          this.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
          setTimeout(() => {
            this.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
          }, 2000);
        } catch (error) {
          alert('Failed to copy API key: ' + error.message);
        }
        document.body.removeChild(tempInput);
      });
    } else {
      // Fallback for environments where navigator.clipboard is unavailable
      const tempInput = document.createElement('input');
      tempInput.value = key;
      document.body.appendChild(tempInput);
      tempInput.select();
      try {
        document.execCommand('copy');
        this.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
        setTimeout(() => {
          this.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
        }, 2000);
      } catch (error) {
        alert('Failed to copy API key: ' + error.message);
      }
      document.body.removeChild(tempInput);
    }
  });
});

// Handle dynamically added copy buttons for cekapikey response
document.addEventListener('click', function(event) {
  if (event.target.closest('.copy-api-btn')) {
    const btn = event.target.closest('.copy-api-btn');
    const key = btn.getAttribute('data-key');
    if (navigator.clipboard) {
      navigator.clipboard.writeText(key).then(() => {
        btn.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
        setTimeout(() => {
          btn.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
        }, 2000);
      }).catch(err => {
        // Fallback for older browsers
        const tempInput = document.createElement('input');
        tempInput.value = key;
        document.body.appendChild(tempInput);
        tempInput.select();
        try {
          document.execCommand('copy');
          btn.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
          setTimeout(() => {
            btn.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
          }, 2000);
        } catch (error) {
          alert('Failed to copy API key: ' + error.message);
        }
        document.body.removeChild(tempInput);
      });
    } else {
      // Fallback for environments where navigator.clipboard is unavailable
      const tempInput = document.createElement('input');
      tempInput.value = key;
      document.body.appendChild(tempInput);
      tempInput.select();
      try {
        document.execCommand('copy');
        btn.innerHTML = '<i class="fas fa-check mr-1"></i> Copied!';
        setTimeout(() => {
          btn.innerHTML = '<i class="fas fa-copy mr-1"></i> Copy';
        }, 2000);
      } catch (error) {
        alert('Failed to copy API key: ' + error.message);
      }
      document.body.removeChild(tempInput);
    }
  }
});
</script>



      <?php endif; ?>
<?php elseif ($page === 'register'): ?>
  <div class="bg-white p-8 rounded-xl shadow-md max-w-md mx-auto">
    <div class="text-center mb-6">
      <h2 class="text-3xl font-bold text-gray-800 mb-2">Create Account</h2>
      <p class="text-gray-600">Join thousands of developers using BetaAPI</p>
    </div>
    
    <form method="post">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
              <i class="fas fa-user"></i>
            </span>
            <input type="text" name="username" class="pl-10 w-full form-control" placeholder="Your username" required>
          </div>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
              <i class="fas fa-envelope"></i>
            </span>
            <input type="email" name="email" class="pl-10 w-full form-control" placeholder="your@email.com" required>
          </div>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
              <i class="fas fa-lock"></i>
            </span>
            <input type="password" name="password" class="pl-10 w-full form-control" placeholder="•••••" required minlength="6">
          </div>
        </div>
        
        <div class="flex items-center">
          <input type="checkbox" id="terms" class="form-checkbox h-4 w-4 text-blue-600" required>
          <label for="terms" class="ml-2 block text-sm text-gray-600">
            I agree to the <a href="?page=terms-of-service" class="text-blue-600 hover:underline">Terms of Service</a>
          </label>
        </div>
      </div>
      
      <button name="register" class="btn btn-primary w-full mt-6 py-3">
        <i class="fas fa-user-plus mr-2"></i> Create Account
      </button>
    </form>
    
<a href="<?php echo htmlspecialchars($googleClient->createAuthUrl()); ?>" class="flex items-center justify-center w-full py-3 bg-white border border-gray-300 rounded-lg text-gray-800 font-medium hover:bg-gray-50 transition-colors mt-4">
  <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google Logo" class="h-5 mr-2">
  Register with Google
</a>
<a href="https://github.com/login/oauth/authorize?client_id=<?php echo urlencode($githubClientId); ?>&redirect_uri=<?php echo urlencode($githubRedirectUri); ?>&scope=user:email" class="flex items-center justify-center w-full py-3 bg-white border border-gray-300 rounded-lg text-gray-800 font-medium hover:bg-gray-50 transition-colors mt-2">
  <img src="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png" alt="GitHub Logo" class="h-5 mr-2">
  Register with GitHub
</a>

<div class="text-center mt-4">
  <p class="text-sm text-gray-600">
    Already have an account? 
    <a href="?page=login" class="text-blue-600 font-medium hover:underline">Sign in</a>
    or <a href="?page=login" class="text-blue-600 font-medium hover:underline">Login with Google</a>
  </p>
</div>
</div>
  <?php elseif ($page === 'login'): ?>
  <div class="bg-white p-8 rounded-xl shadow-md max-w-md mx-auto">
    <div class="text-center mb-6">
      <h2 class="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h2>
      <p class="text-gray-600">Sign in to access your API dashboard</p>
    </div>
    
    <form method="post">
      <div class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
              <i class="fas fa-envelope"></i>
            </span>
            <input type="email" name="email" class="pl-10 w-full form-control" placeholder="your@email.com" required>
          </div>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <div class="relative">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
              <i class="fas fa-lock"></i>
            </span>
            <input type="password" name="password" class="pl-10 w-full form-control" placeholder="••••••" required>
          </div>
        </div>
        
        <div class="flex items-center justify-between">
          <div class="flex items-center">
            <input type="checkbox" id="remember" class="form-checkbox h-4 w-4 text-blue-600">
            <label for="remember" class="ml-2 block text-sm text-gray-600">Remember me</label>
          </div>
          <a href="?page=forgot-password" class="text-sm text-blue-600 hover:underline">Forgot password?</a>
        </div>
      </div>
      
      <button name="login" class="btn btn-primary w-full mt-6 py-3">
        <i class="fas fa-sign-in-alt mr-2"></i> Sign In
      </button>
    </form>
    
<div class="mt-4">
  <a href="<?php echo htmlspecialchars($googleClient->createAuthUrl()); ?>" class="flex items-center justify-center w-full py-3 bg-white border border-gray-300 rounded-lg text-gray-800 font-medium hover:bg-gray-50 transition-colors">
    <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google Logo" class="h-5 mr-2">
    Login with Google
  </a>
  <a href="https://github.com/login/oauth/authorize?client_id=<?php echo urlencode($githubClientId); ?>&redirect_uri=<?php echo urlencode($githubRedirectUri); ?>&scope=user:email" class="flex items-center justify-center w-full py-3 bg-white border border-gray-300 rounded-lg text-gray-800 font-medium hover:bg-gray-50 transition-colors mt-2">
    <img src="https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png" alt="GitHub Logo" class="h-5 mr-2">
    Login with GitHub
  </a>
</div>

<div class="text-center mt-4">
  <p class="text-sm text-gray-600">
    Don't have an account? 
    <a href="?page=register" class="text-blue-600 font-medium hover:underline">Register</a>
  </p>
</div>
</div>
    <?php elseif ($page === 'forgot-password'): ?>
      <div class="bg-white p-8 rounded-xl shadow-md max-w-md mx-auto">
        <div class="text-center mb-6">
          <h2 class="text-3xl font-bold text-gray-800 mb-2">Reset Password</h2>
          <p class="text-gray-600">Enter your email to receive a password reset link</p>
        </div>
        
        <form method="post">
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <div class="relative">
              <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                <i class="fas fa-envelope"></i>
              </span>
              <input type="email" name="email" class="pl-10 w-full form-control" placeholder="your@email.com" required>
            </div>
          </div>
          
          <button name="request_reset" class="btn btn-primary w-full mt-6 py-3">
            <i class="fas fa-key mr-2"></i> Request Reset Link
          </button>
          
          <div class="text-center mt-4">
            <p class="text-sm text-gray-600">
              Remember your password? 
              <a href="?page=login" class="text-blue-600 font-medium hover:underline">Sign in</a>
            </p>
          </div>
        </form>
      </div>

    <?php elseif ($page === 'reset-password'): ?>
      <?php
      $email = $_GET['email'] ?? '';
      $token = $_GET['token'] ?? '';
      $validToken = isset($passwordResetTokens[$email]) && 
                    $passwordResetTokens[$email]['token'] === $token && 
                    $passwordResetTokens[$email]['expires'] > time();
      
      if (!$validToken): ?>
        <div class="bg-white p-8 rounded-xl shadow-md max-w-md mx-auto text-center">
          <div class="text-red-500 text-5xl mb-4">
            <i class="fas fa-exclamation-circle"></i>
          </div>
          <h2 class="text-2xl font-bold text-gray-800 mb-2">Invalid or Expired Link</h2>
          <p class="text-gray-600 mb-4">The password reset link is invalid or has expired.</p>
          <a href="?page=forgot-password" class="btn btn-primary">
            <i class="fas fa-key mr-2"></i> Request New Reset Link
          </a>
        </div>
      <?php else: ?>
        <div class="bg-white p-8 rounded-xl shadow-md max-w-md mx-auto">
          <div class="text-center mb-6">
            <h2 class="text-3xl font-bold text-gray-800 mb-2">Set New Password</h2>
            <p class="text-gray-600">Enter a new password for <?= htmlspecialchars($email) ?></p>
          </div>
          
          <form method="post">
            <div class="space-y-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                <div class="relative">
                  <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                    <i class="fas fa-lock"></i>
                  </span>
                  <input type="password" name="new_password" class="pl-10 w-full form-control" placeholder="•••••" required minlength="6">
                </div>
              </div>
              
              <div>
  <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
  <div class="relative">
    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
      <i class="fas fa-lock"></i>
    </span>
    <input type="password" name="confirm_password" class="pl-10 w-full form-control" placeholder="•••••" required minlength="6">
  </div>
</div>

            
            <button name="reset_password" class="btn btn-primary w-full mt-6 py-3">
              <i class="fas fa-save mr-2"></i> Update Password
            </button>
            
            <div class="text-center mt-4">
              <p class="text-sm text-gray-600">
                Remember your password? 
                <a href="?page=login" class="text-blue-600 font-medium hover:underline">Sign in</a>
              </p>
            </div>
          </form>
        </div>
      <?php endif; ?>

    <?php elseif ($page === 'logout'): ?>
      <?php
      session_unset();
      session_destroy();
      header('Location: ?page=login');
      exit();
      ?>
    <?php endif; ?>
  </div>
</main>

<!-- Footer -->
<footer class="bg-white py-6 border-t">
  <div class="container text-center text-gray-600">
    <p>&copy; <?= date('Y') ?> BetaAPI. All rights reserved.</p>
    <div class="flex justify-center space-x-4 mt-2">
      <a href="https://x.com/AdivStudio50585?t=izBk_sCoF99r-VZLDu05BQ&s=09" class="hover:text-blue-600"><i class="fab fa-twitter"></i></a>
      <a href="https://github.com/ADIVSTUDIO13" class="hover:text-blue-600"><i class="fab fa-github"></i></a>
      <a href="#" class="hover:text-blue-600"><i class="fab fa-discord"></i></a>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>