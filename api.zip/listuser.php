<?php
session_start();

// Admin credentials (for development only)
$adminCredentials = [
    'username' => 'admin',
    'password' => 'admin123'
];

// File paths
$usersFile = 'users.json';
$backupDir = 'backups/';

// Create backup directory if not exists
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if ($username === $adminCredentials['username'] && $password === $adminCredentials['password']) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['login_time'] = time();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $loginError = 'Invalid username or password';
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if admin is logged in
$isLoggedIn = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

// Load user data
$users = [];
if ($isLoggedIn && file_exists($usersFile)) {
    $jsonData = file_get_contents($usersFile);
    $users = json_decode($jsonData, true) ?: [];
}

// Function to save user data
function saveUserData($filePath, $data, $backupDir) {
    // Create backup before saving
    if (file_exists($filePath)) {
        $backupFile = $backupDir . 'users_backup_' . date('Y-m-d_H-i-s') . '.json';
        copy($filePath, $backupFile);
    }
    
    // Save new data
    file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT));
}

// Handle CRUD operations
if ($isLoggedIn && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create new user
    if (isset($_POST['create_user'])) {
        $newUser = [
            'email' => trim($_POST['email']),
            'username' => trim($_POST['username']),
            'password' => $_POST['password'] ? password_hash($_POST['password'], PASSWORD_BCRYPT) : null,
            'auth_provider' => $_POST['auth_provider'],
            'email_verified' => isset($_POST['email_verified']),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Add optional fields
        if (!empty($_POST['api_keys'])) {
            $newUser['api_keys'] = json_decode($_POST['api_keys'], true);
        }
        
        $users[$newUser['email']] = $newUser;
        saveUserData($usersFile, $users, $backupDir);
        $_SESSION['success_message'] = 'User created successfully!';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    // Update user
    if (isset($_POST['update_user'])) {
        $originalEmail = $_POST['original_email'];
        $updatedUser = [
            'email' => trim($_POST['email']),
            'username' => trim($_POST['username']),
            'auth_provider' => $_POST['auth_provider'],
            'email_verified' => isset($_POST['email_verified']),
            'created_at' => $users[$originalEmail]['created_at']
        ];
        
        // Preserve password if not changed
        if (!empty($_POST['password'])) {
            $updatedUser['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT);
        } else {
            $updatedUser['password'] = $users[$originalEmail]['password'] ?? null;
        }
        
        // Preserve API keys if not changed
        if (isset($users[$originalEmail]['api_keys'])) {
            $updatedUser['api_keys'] = $users[$originalEmail]['api_keys'];
        }
        
        // Preserve other existing fields
        foreach ($users[$originalEmail] as $key => $value) {
            if (!array_key_exists($key, $updatedUser)) {
                $updatedUser[$key] = $value;
            }
        }
        
        // If email changed, remove old entry
        if ($originalEmail !== $updatedUser['email']) {
            unset($users[$originalEmail]);
        }
        
        $users[$updatedUser['email']] = $updatedUser;
        saveUserData($usersFile, $users, $backupDir);
        $_SESSION['success_message'] = 'User updated successfully!';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    // Delete user
    if (isset($_POST['delete_user'])) {
        $emailToDelete = $_POST['email_to_delete'];
        if (isset($users[$emailToDelete])) {
            unset($users[$emailToDelete]);
            saveUserData($usersFile, $users, $backupDir);
            $_SESSION['success_message'] = 'User deleted successfully!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
    
    // Verify email
    if (isset($_POST['verify_email'])) {
        $emailToVerify = $_POST['email_to_verify'];
        if (isset($users[$emailToVerify])) {
            $users[$emailToVerify]['email_verified'] = true;
            saveUserData($usersFile, $users, $backupDir);
            $_SESSION['success_message'] = 'Email verified successfully!';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

// Handle search and filtering
$searchQuery = $_GET['search'] ?? '';
$filterType = $_GET['filter'] ?? 'all';

// Calculate statistics
$stats = [
    'total_users' => count($users),
    'verified_emails' => 0,
    'local_accounts' => 0,
    'social_accounts' => 0,
    'active_api_keys' => 0
];

foreach ($users as $user) {
    if (isset($user['email_verified']) && $user['email_verified']) {
        $stats['verified_emails']++;
    }
    if (isset($user['auth_provider'])) {
        if ($user['auth_provider'] === 'local') {
            $stats['local_accounts']++;
        } else {
            $stats['social_accounts']++;
        }
    }
    if (isset($user['api_keys'])) {
        $stats['active_api_keys'] += count($user['api_keys']);
    }
}

// Apply filters
$filteredUsers = [];
foreach ($users as $email => $user) {
    $matchesSearch = empty($searchQuery) || 
                     stripos($email, $searchQuery) !== false || 
                     stripos($user['username'], $searchQuery) !== false;
    
    $matchesFilter = true;
    if ($filterType !== 'all') {
        if ($filterType === 'verified') {
            $matchesFilter = isset($user['email_verified']) && $user['email_verified'];
        } elseif ($filterType === 'unverified') {
            $matchesFilter = !isset($user['email_verified']) || !$user['email_verified'];
        } elseif ($filterType === 'local') {
            $matchesFilter = isset($user['auth_provider']) && $user['auth_provider'] === 'local';
        } elseif ($filterType === 'social') {
            $matchesFilter = isset($user['auth_provider']) && $user['auth_provider'] !== 'local';
        }
    }
    
    if ($matchesSearch && $matchesFilter) {
        $filteredUsers[$email] = $user;
    }
}

// Function to display data
function displayData($data, $depth = 0) {
    if (is_null($data)) {
        return '<span class="null">null</span>';
    } elseif (is_bool($data)) {
        return '<span class="bool">' . ($data ? 'true' : 'false') . '</span>';
    } elseif (is_array($data) || is_object($data)) {
        if (empty($data)) {
            return '<span class="empty">[]</span>';
        }
        $output = '<ul style="margin-left: ' . ($depth * 20) . 'px;">';
        foreach ($data as $key => $value) {
            $output .= '<li><strong>' . htmlspecialchars($key) . ':</strong> ' . displayData($value, $depth + 1) . '</li>';
        }
        $output .= '</ul>';
        return $output;
    } else {
        return '<span>' . htmlspecialchars($data) . '</span>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data Manager</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #2ecc71;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: var(--secondary-color);
        }
        
        .navbar-brand {
            font-weight: 700;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            color: white;
            margin-bottom: 20px;
        }
        
        .stat-card .stat-value {
            font-size: 2.5rem;
            font-weight: bold;
        }
        
        .stat-card .stat-label {
            font-size: 1rem;
            opacity: 0.9;
        }
        
        .user-card {
            margin-bottom: 20px;
            border-left: 4px solid var(--primary-color);
        }
        
        .user-email {
            font-weight: 600;
            color: var(--primary-color);
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }
        
        .action-btn {
            margin-right: 5px;
            font-size: 0.9rem;
        }
        
        .security-warning {
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        
        .null {
            color: #6c757d;
            font-style: italic;
        }
        
        .bool {
            font-weight: bold;
        }
        
        .bool.true {
            color: var(--success-color);
        }
        
        .bool.false {
            color: var(--danger-color);
        }
        
        .empty {
            color: #adb5bd;
        }
        
        #rawJsonContainer {
            display: none;
            margin-top: 20px;
        }
        
        .tab-content {
            padding: 20px 0;
        }
        
        .nav-tabs .nav-link.active {
            font-weight: 600;
            border-bottom: 3px solid var(--primary-color);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-users-cog me-2"></i>User Manager
            </a>
            <?php if ($isLoggedIn): ?>
                <div class="d-flex align-items-center">
                    <span class="text-white me-3">
                        <i class="fas fa-user-circle me-1"></i> <?= htmlspecialchars($adminCredentials['username']) ?>
                    </span>
                    <a href="?logout=1" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-sign-out-alt me-1"></i> Logout
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </nav>

    <div class="container">
        <?php if (!$isLoggedIn): ?>
            <!-- Login Form -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-white">
                            <h4 class="mb-0 text-center"><i class="fas fa-sign-in-alt me-2"></i>Admin Login</h4>
                        </div>
                        <div class="card-body">
                            <?php if (isset($loginError)): ?>
                                <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
                            <?php endif; ?>
                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" required value="admin">
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" required value="admin123">
                                </div>
                                <button type="submit" name="login" class="btn btn-primary w-100">
                                    <i class="fas fa-sign-in-alt me-1"></i> Login
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Main Content -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($_SESSION['success_message']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            
            <div class="alert alert-warning security-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>SECURITY WARNING:</strong> This is a development tool with plain text credentials. Never use in production!
            </div>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stat-card bg-primary">
                        <div class="stat-value"><?= $stats['total_users'] ?></div>
                        <div class="stat-label">Total Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card bg-success">
                        <div class="stat-value"><?= $stats['verified_emails'] ?? 0 ?></div>
                        <div class="stat-label">Verified Emails</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card bg-info">
                        <div class="stat-value"><?= $stats['local_accounts'] ?></div>
                        <div class="stat-label">Local Accounts</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card bg-warning">
                        <div class="stat-value"><?= $stats['social_accounts'] ?></div>
                        <div class="stat-label">Social Accounts</div>
                    </div>
                </div>
            </div>
            
            <!-- Tabs Navigation -->
            <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="dashboard-tab" data-bs-toggle="tab" data-bs-target="#dashboard" type="button" role="tab">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="create-tab" data-bs-toggle="tab" data-bs-target="#create" type="button" role="tab">
                        <i class="fas fa-user-plus me-2"></i>Create User
                    </button>
                </li>
            </ul>
            
            <!-- Tabs Content -->
            <div class="tab-content" id="myTabContent">
                <!-- Dashboard Tab -->
                <div class="tab-pane fade show active" id="dashboard" role="tabpanel">
                    <!-- Search and Filter -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                                        <input type="text" class="form-control" id="search" placeholder="Search users..." 
                                               value="<?= htmlspecialchars($searchQuery) ?>">
                                        <button class="btn btn-primary" onclick="performSearch()">Search</button>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <select class="form-select" id="filter" onchange="performSearch()">
                                        <option value="all" <?= $filterType === 'all' ? 'selected' : '' ?>>All Users</option>
                                        <option value="verified" <?= $filterType === 'verified' ? 'selected' : '' ?>>Verified Only</option>
                                        <option value="unverified" <?= $filterType === 'unverified' ? 'selected' : '' ?>>Unverified Only</option>
                                        <option value="local" <?= $filterType === 'local' ? 'selected' : '' ?>>Local Accounts</option>
                                        <option value="social" <?= $filterType === 'social' ? 'selected' : '' ?>>Social Accounts</option>
                                    </select>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    Showing <?= count($filteredUsers) ?> of <?= count($users) ?> users
                                </div>
                                <button class="btn btn-sm btn-outline-secondary" onclick="toggleRawJson()">
                                    <i class="fas fa-code me-1"></i> Toggle Raw JSON
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Users List -->
                    <div class="row" id="users-container">
                        <?php foreach ($filteredUsers as $email => $userData): ?>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100 user-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-3">
                                            <h5 class="card-title user-email mb-0"><?= htmlspecialchars($email) ?></h5>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                    <i class="fas fa-cog"></i>
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <a class="dropdown-item" href="#" onclick="openEditModal('<?= htmlspecialchars($email) ?>')">
                                                            <i class="fas fa-edit me-2"></i>Edit
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item text-danger" href="#" onclick="confirmDelete('<?= htmlspecialchars($email) ?>')">
                                                            <i class="fas fa-trash-alt me-2"></i>Delete
                                                        </a>
                                                    </li>
                                                    <?php if (isset($userData['email_verified']) && !$userData['email_verified']): ?>
                                                    <li>
                                                        <form method="POST" class="d-inline">
                                                            <input type="hidden" name="email_to_verify" value="<?= htmlspecialchars($email) ?>">
                                                            <button type="submit" name="verify_email" class="dropdown-item text-success">
                                                                <i class="fas fa-check-circle me-2"></i>Verify Email
                                                            </button>
                                                        </form>
                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                        
                                        <div class="user-details">
                                            <?= displayData($userData) ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Raw JSON View -->
                    <div class="card" id="rawJsonContainer">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-code me-2"></i>Raw JSON Data</h5>
                        </div>
                        <div class="card-body">
                            <pre class="bg-light p-3 rounded"><?= htmlspecialchars(json_encode($users, JSON_PRETTY_PRINT)) ?></pre>
                        </div>
                    </div>
                </div>
                
                <!-- Create User Tab -->
                <div class="tab-pane fade" id="create" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-user-plus me-2"></i>Create New User</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="password" class="form-label">Password (leave empty for social accounts)</label>
                                        <input type="password" class="form-control" id="password" name="password">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="auth_provider" class="form-label">Authentication Provider</label>
                                        <select class="form-select" id="auth_provider" name="auth_provider" required>
                                            <option value="local">Local</option>
                                            <option value="github">GitHub</option>
                                            <option value="google">Google</option>
                                            <option value="facebook">Facebook</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="email_verified" name="email_verified">
                                    <label class="form-check-label" for="email_verified">Email Verified</label>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="api_keys" class="form-label">API Keys (JSON format)</label>
                                    <textarea class="form-control font-monospace" id="api_keys" name="api_keys" rows="5" placeholder='{"API-123": {"name": "Test", "created_at": "2023-01-01"}}'></textarea>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" name="create_user" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Create User
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Edit User Modal -->
            <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><i class="fas fa-user-edit me-2"></i>Edit User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form method="POST" id="editForm">
                            <div class="modal-body">
                                <input type="hidden" name="original_email" id="original_email">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="edit_email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="edit_email" name="email" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="edit_username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="edit_username" name="username" required>
                                    </div>
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="edit_password" class="form-label">New Password (leave empty to keep current)</label>
                                        <input type="password" class="form-control" id="edit_password" name="password">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="edit_auth_provider" class="form-label">Authentication Provider</label>
                                        <select class="form-select" id="edit_auth_provider" name="auth_provider" required>
                                            <option value="local">Local</option>
                                            <option value="github">GitHub</option>
                                            <option value="google">Google</option>
                                            <option value="facebook">Facebook</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="edit_email_verified" name="email_verified">
                                    <label class="form-check-label" for="edit_email_verified">Email Verified</label>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="edit_api_keys" class="form-label">API Keys (JSON format)</label>
                                    <textarea class="form-control font-monospace" id="edit_api_keys" name="api_keys" rows="5"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                    <i class="fas fa-times me-2"></i>Cancel
                                </button>
                                <button type="submit" name="update_user" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Bootstrap 5 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Custom JS -->
    <script>
        // Search functionality
        function performSearch() {
            const searchQuery = $('#search').val();
            const filterType = $('#filter').val();
            window.location.href = `?search=${encodeURIComponent(searchQuery)}&filter=${filterType}`;
        }
        
        // Toggle raw JSON view
        function toggleRawJson() {
            $('#rawJsonContainer').toggle();
        }
        
        // Edit modal
        function openEditModal(email) {
            const user = <?= json_encode($users) ?>[email];
            $('#original_email').val(email);
            $('#edit_email').val(email);
            $('#edit_username').val(user.username || '');
            $('#edit_auth_provider').val(user.auth_provider || 'local');
            $('#edit_email_verified').prop('checked', user.email_verified || false);
            $('#edit_api_keys').val(JSON.stringify(user.api_keys || {}, null, 2));
            
            const editModal = new bootstrap.Modal(document.getElementById('editModal'));
            editModal.show();
        }
        
        // Delete confirmation
        function confirmDelete(email) {
            Swal.fire({
                title: 'Confirm Deletion',
                text: `Are you sure you want to delete user ${email}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Create a form and submit it
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '';
                    
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'email_to_delete';
                    input.value = email;
                    
                    const deleteInput = document.createElement('input');
                    deleteInput.type = 'hidden';
                    deleteInput.name = 'delete_user';
                    deleteInput.value = '1';
                    
                    form.appendChild(input);
                    form.appendChild(deleteInput);
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }
        
        // Initialize tooltips
        $(function () {
            $('[data-bs-toggle="tooltip"]').tooltip();
        });
    </script>
</body>
</html>